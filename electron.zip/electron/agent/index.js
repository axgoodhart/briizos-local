/**
 * In-process agent runtime — public API.
 *
 * Runtime-compatible replacement for the former external agent process. Same function
 * names + signatures so electron/main.js IPC handlers and preload.js
 * keep working unchanged. Zero Python in the runtime path; no HTTP
 * tool-bridge; no `uv run langgraph dev`; no uvicorn gateway.
 *
 * Lifecycle:
 *   - start() / stop() are now trivial (nothing to spawn). They remain
 *     for API parity with main.js's startup hooks.
 *   - getStatus() always reports 'running' once start() has been called,
 *     so useChat.checkConfig() resolves cleanly.
 *
 * Threading:
 *   - createThread() returns a fresh thread_id; multi-turn context is
 *     persisted by the configured in-process LangGraph checkpointer.
 *
 * Streaming:
 *   - streamMessage / resumeRun forward each agent SSE-shaped event to
 *     onEvent(type, payload). main.js wraps onEvent so the renderer
 *     receives them on the existing 'langgraph-stream-event' channel —
 *     useChat needs no change.
 */

const crypto = require('crypto');
const { logger } = require('../logger');
const bridge = require('./bridge');
const leadAgent = require('./lead-agent');
const codexProvider = require('../codex-provider');
const { getCheckpointerStatus } = require('./checkpointer');

const state = {
  status: 'idle',
  startedAt: null,
};

function setMainWindow(win) {
  bridge.setMainWindow(win);
}

function setLocalDataService(service) {
  leadAgent.setLocalDataService(service);
  codexProvider.setLocalDataService(service);
}

function isCodexConfig(config = {}) {
  const modelName = config.model_name || config.model || null;
  return leadAgent.getLocalDataService()?.getModelProfile?.(modelName)?.provider === 'codex';
}

async function start() {
  state.status = 'running';
  state.startedAt = Date.now();
  logger.debug('agent', 'Local AI graph code initialized inside the Electron process', {
    providerRequestAttempted: false,
    explanation: 'This is an internal initialization step, not proof that a model provider is reachable or has quota.',
  });
  return true;
}

function stop() {
  state.status = 'stopped';
  leadAgent.resetCache();
  codexProvider.stop();
  logger.info('agent', 'The local AI request engine stopped; no new model requests can start until briizOS reopens.');
}

function getStatus() {
  return {
    status: state.status,
    ready: state.status === 'running',
    port: null,
    pid: process.pid,
    uptime: state.startedAt ? Math.floor((Date.now() - state.startedAt) / 1000) : null,
    inProcess: true,
    checkpointer: getCheckpointerStatus(),
  };
}

async function createThread(kind = 'chat') {
  const threadId = crypto.randomUUID();
  const service = leadAgent.getLocalDataService();
  if (!service) throw new Error('Local data is not ready');
  service.createThread({ id: threadId, kind });
  return threadId;
}

function withConfiguredActivity(threadId, config, work) {
  const activityId = config?.activity_id || config?.activityId || null;
  if (!activityId) return work();
  return logger.withActivity({
    activityId,
    threadId,
    taskId: config?.task_id || config?.taskId || null,
  }, work);
}

async function streamMessage(threadId, message, config, onEvent) {
  if (typeof onEvent !== 'function') onEvent = () => {};
  const safeConfig = config || {};
  return withConfiguredActivity(threadId, safeConfig, () => (
    isCodexConfig(safeConfig)
      ? codexProvider.streamTurn(threadId, message, safeConfig, onEvent)
      : leadAgent.streamTurn({ threadId, message, config: safeConfig, onEvent })
  ));
}

async function resumeRun(threadId, response, config, onEvent) {
  if (typeof onEvent !== 'function') onEvent = () => {};
  const safeConfig = config || {};
  return withConfiguredActivity(threadId, safeConfig, () => (
    leadAgent.resumeTurn({ threadId, response: response || {}, config: safeConfig, onEvent })
  ));
}

async function sendMessage(threadId, message, config) {
  const safeConfig = config || {};
  return withConfiguredActivity(threadId, safeConfig, () => {
    if (!isCodexConfig(safeConfig)) return leadAgent.sendTurn({ threadId, message, config: safeConfig });
    let content = '';
    return codexProvider.streamTurn(threadId, message, safeConfig, (type, payload) => {
      if (type === 'text') content += payload?.content || '';
    }).then((result) => ({ ...result, content }));
  });
}

async function fetchSuggestions(recentMessages, n = 3, config = {}, threadId = null) {
  const safeConfig = config || {};
  if (isCodexConfig(safeConfig)) return [];
  return withConfiguredActivity(threadId, safeConfig, () => (
    leadAgent.generateSuggestions({
      threadId,
      recentMessages: recentMessages || [],
      n,
      config: safeConfig,
    })
  ));
}

module.exports = {
  setMainWindow,
  setLocalDataService,
  start,
  stop,
  getStatus,
  createThread,
  streamMessage,
  resumeRun,
  sendMessage,
  fetchSuggestions,
};
