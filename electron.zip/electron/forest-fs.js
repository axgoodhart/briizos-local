/**
 * Forest filesystem tools — board state (the infinite-forest project board),
 * dropped-file import, and the Hunter/FileHawk search/repair utilities.
 *
 * Ported from Projungle's main.js. Storage stays local-only for now (a JSON
 * file in userData), same local-only stance as forest-db.js — not routed
 * through Firestore/SyncContract.
 */
const path = require('path');
const fs = require('fs/promises');
const crypto = require('crypto');
const os = require('os');
const { app } = require('electron');
const { isHidden, isIgnored } = require('./forest-ignore');
const {
  FOREST_MAX_FILES_PER_PROJECT,
  FOREST_MAX_FILES_PER_DROP,
  FOREST_MAX_SCAN_ENTRIES,
} = require('./local-data/limits');

function getStateFilePath() {
  return path.join(app.getPath('userData'), 'forest.library.json');
}

function defaultState() {
  return {
    version: 1,
    viewport: { x: 260, y: 160, scale: 1 },
    projects: [],
  };
}

async function loadState() {
  try {
    const raw = await fs.readFile(getStateFilePath(), 'utf8');
    const parsed = JSON.parse(raw);

    return {
      ...defaultState(),
      ...parsed,
      viewport: {
        ...defaultState().viewport,
        ...(parsed.viewport || {}),
      },
      projects: Array.isArray(parsed.projects) ? parsed.projects : [],
    };
  } catch {
    return defaultState();
  }
}

async function saveState(state) {
  const payload = {
    version: 1,
    viewport: state?.viewport || defaultState().viewport,
    projects: Array.isArray(state?.projects) ? state.projects : [],
  };

  await fs.mkdir(path.dirname(getStateFilePath()), { recursive: true });
  await fs.writeFile(getStateFilePath(), JSON.stringify(payload, null, 2), 'utf8');

  return { ok: true };
}

const EXT_GROUPS = {
  image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'tif', 'tiff', 'avif', 'heic'],
  video: ['mp4', 'mov', 'm4v', 'avi', 'mkv', 'webm', 'wmv', 'flv'],
  audio: ['mp3', 'wav', 'aiff', 'aac', 'ogg', 'm4a', 'flac'],
  pdf: ['pdf'],
  document: ['doc', 'docx', 'rtf', 'txt', 'md', 'pages'],
  spreadsheet: ['xls', 'xlsx', 'csv', 'numbers'],
  slides: ['ppt', 'pptx', 'key'],
  design: ['fig', 'sketch', 'xd', 'psd', 'ai', 'indd'],
  code: [
    'js', 'ts', 'tsx', 'jsx', 'html', 'css', 'scss', 'less',
    'json', 'yaml', 'yml', 'xml', 'py', 'rb', 'php',
    'java', 'c', 'cpp', 'h', 'hpp', 'go', 'rs', 'swift',
    'kt', 'sql', 'sh', 'bash',
  ],
  archive: ['zip', 'rar', '7z', 'tar', 'gz', 'tgz'],
  model: ['blend', 'obj', 'fbx', 'glb', 'gltf', 'stl'],
  data: ['db', 'sqlite', 'parquet'],
};

const GENERIC_PROJECT_NAMES = new Set([
  'desktop', 'documents', 'document', 'downloads', 'download', 'files', 'file',
  'assets', 'photos', 'pictures', 'images', 'music', 'audio', 'video', 'movies',
  'library', 'work', 'projects', 'project', 'untitled', 'misc', 'stuff',
]);

const TOKEN_STOPWORDS = new Set([
  'the', 'and', 'for', 'from', 'with', 'that', 'this', 'into', 'your', 'copy',
  'draft', 'final', 'new', 'old', 'version', 'export', 'edited', 'edit',
  'screen', 'shot', 'img', 'image', 'doc', 'file', 'untitled',
]);

// Ignore rules (node_modules, VCS, build output, OS junk, hidden entries)
// live in forest-ignore.js — a .gitignore-style default list shared by
// board imports and the Hunter/FileHawk scans below.

function typeGroupFromExt(ext) {
  const clean = String(ext || '').replace(/^\./, '').toLowerCase();
  for (const [group, extensions] of Object.entries(EXT_GROUPS)) {
    if (extensions.includes(clean)) return group;
  }
  return 'other';
}

function titleCase(value) {
  return String(value || '')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function tokenize(value) {
  return String(value || '')
    .toLowerCase()
    .split(/[^a-z0-9]+/g)
    .filter((token) => token && token.length > 1 && !TOKEN_STOPWORDS.has(token));
}

function hashId(value) {
  return crypto.createHash('sha1').update(String(value)).digest('hex').slice(0, 12);
}

function smartProjectLabelFromFile(filePath, typeGroup) {
  const baseName = path.basename(filePath, path.extname(filePath));
  const tokens = tokenize(baseName).filter((token) => {
    if (GENERIC_PROJECT_NAMES.has(token)) return false;
    if (/^v?\d+$/.test(token)) return false;
    return true;
  });

  if (tokens.length) return titleCase(tokens[0]);

  const fallbackNames = {
    image: 'Images', video: 'Videos', audio: 'Audio', pdf: 'PDFs',
    document: 'Documents', spreadsheet: 'Sheets', slides: 'Slides',
    design: 'Design', code: 'Code', archive: 'Archives', model: '3D',
    data: 'Data', other: 'Loose Files',
  };

  return fallbackNames[typeGroup] || 'Loose Files';
}

function inferTags() {
  return [];
}

function buildFileRecord(filePath, stat, projectHint) {
  const ext = path.extname(filePath).slice(1).toLowerCase();
  const typeGroup = typeGroupFromExt(ext);

  return {
    id: `file-${hashId(filePath)}`,
    name: path.basename(filePath),
    path: filePath,
    ext,
    size: stat.size,
    modifiedAt: stat.mtime.toISOString(),
    typeGroup,
    previewable: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'avif', 'heic', 'mp4', 'mov', 'm4v', 'webm', 'mp3', 'wav', 'aiff', 'aac', 'ogg', 'm4a', 'flac'].includes(ext),
    tags: inferTags(filePath, ext, typeGroup, stat),
    projectHint,
  };
}

async function walkInputPath(entryPath, projectHint, output, seenPaths, stats, isRoot = false) {
  if (stats.aborted || stats.overflow) return;

  stats.scanned += 1;
  if (stats.scanned > FOREST_MAX_SCAN_ENTRIES) {
    stats.aborted = true;
    return;
  }

  let stat;
  try {
    stat = await fs.lstat(entryPath);
  } catch {
    return;
  }

  const baseName = path.basename(entryPath);

  if (stat.isSymbolicLink()) return;

  // .gitignore-style filtering. Explicitly dropped roots are exempt so a
  // hidden or ignored folder can still be imported on purpose.
  if (!isRoot && (isHidden(baseName) || isIgnored(baseName, stat.isDirectory()))) {
    stats.ignored += 1;
    return;
  }

  if (stat.isDirectory()) {
    let children = [];
    try {
      children = await fs.readdir(entryPath);
    } catch {
      return;
    }

    for (const child of children) {
      if (stats.aborted || stats.overflow) return;
      await walkInputPath(path.join(entryPath, child), projectHint, output, seenPaths, stats);
    }
    return;
  }

  if (!stat.isFile()) return;

  const resolved = path.resolve(entryPath);
  if (seenPaths.has(resolved)) return;
  seenPaths.add(resolved);

  if (stats.files >= FOREST_MAX_FILES_PER_DROP) {
    stats.overflow = true;
    return;
  }

  stats.files += 1;
  output.push(buildFileRecord(resolved, stat, projectHint));
}

function normalizeProjectKey(name) {
  return String(name || 'Untitled Project').trim().toLowerCase();
}

/**
 * Import dropped paths into project groups.
 *
 * Returns `{ groups, stats, limits }` on success, or
 * `{ groups: [], stats, limits, rejected: { reason, message } }` when the
 * drop would exceed what the board/DB can safely hold — nothing is
 * imported in that case (graceful rejection, decided *before* any state
 * mutation or save attempt).
 */
async function importDroppedPaths(inputPaths = []) {
  const uniqueInputs = Array.from(new Set((inputPaths || []).filter(Boolean)));
  const seenFiles = new Set();
  const groups = new Map();
  const stats = { scanned: 0, files: 0, ignored: 0, aborted: false, overflow: false };
  const limits = {
    maxFilesPerProject: FOREST_MAX_FILES_PER_PROJECT,
    maxFilesPerDrop: FOREST_MAX_FILES_PER_DROP,
  };
  const reject = (reason, message) => ({ groups: [], stats, limits, rejected: { reason, message } });

  for (const rawPath of uniqueInputs) {
    if (stats.aborted || stats.overflow) break;

    const fullPath = path.resolve(rawPath);

    let stat;
    try {
      stat = await fs.lstat(fullPath);
    } catch {
      continue;
    }

    let projectHint;

    if (stat.isDirectory()) {
      projectHint = path.basename(fullPath) || 'Untitled Project';
    } else {
      const parentName = path.basename(path.dirname(fullPath)) || '';
      const ext = path.extname(fullPath).slice(1).toLowerCase();
      const typeGroup = typeGroupFromExt(ext);

      projectHint = !GENERIC_PROJECT_NAMES.has(parentName.toLowerCase())
        ? parentName
        : smartProjectLabelFromFile(fullPath, typeGroup);
    }

    const files = [];
    await walkInputPath(fullPath, projectHint, files, seenFiles, stats, true);

    for (const file of files) {
      const key = normalizeProjectKey(file.projectHint);

      if (!groups.has(key)) {
        groups.set(key, {
          name: titleCase(file.projectHint),
          files: [],
          tagCounts: new Map(),
        });
      }

      const group = groups.get(key);
      group.files.push(file);

      for (const tag of file.tags) {
        group.tagCounts.set(tag, (group.tagCounts.get(tag) || 0) + 1);
      }
    }
  }

  if (stats.overflow) {
    return reject(
      'too-many-files',
      `more than ${FOREST_MAX_FILES_PER_DROP.toLocaleString()} files after ignore filtering — try a smaller folder`,
    );
  }
  if (stats.aborted) {
    return reject(
      'scan-too-large',
      `gave up after scanning ${FOREST_MAX_SCAN_ENTRIES.toLocaleString()} entries — try a smaller folder`,
    );
  }

  const resultGroups = Array.from(groups.values())
    .map((group) => ({
      name: group.name,
      tags: Array.from(group.tagCounts.entries())
        .filter(([tag]) => tag && tag.length > 1)
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
        .map(([tag]) => tag)
        .slice(0, 10),
      files: group.files.sort((a, b) => a.name.localeCompare(b.name)),
    }))
    .sort((a, b) => a.name.localeCompare(b.name));

  const oversized = resultGroups.find((group) => group.files.length > FOREST_MAX_FILES_PER_PROJECT);
  if (oversized) {
    return reject(
      'project-too-large',
      `"${oversized.name}" would hold ${oversized.files.length.toLocaleString()} files (max ${FOREST_MAX_FILES_PER_PROJECT.toLocaleString()} per project) — try a subfolder`,
    );
  }

  return { groups: resultGroups, stats, limits };
}

// ── Hunter ──────────────────────────────────────────────────────────

function hunterDefaultDirs() {
  const homeDir = os.homedir();
  return [
    path.join(homeDir, 'Desktop'),
    path.join(homeDir, 'Documents'),
    path.join(homeDir, 'Downloads'),
    path.join(homeDir, 'Pictures'),
    path.join(homeDir, 'Movies'),
    path.join(homeDir, 'Music'),
  ];
}

async function hunterSearch(keywords = [], excludePaths = [], customDirs = []) {
  const searchDirs = customDirs.length ? customDirs : hunterDefaultDirs();

  const excludeSet = new Set(excludePaths.map((p) => path.resolve(p)));
  const normalizedKeywords = keywords
    .map((k) => String(k).toLowerCase())
    .filter((k) => k.length > 2 && !TOKEN_STOPWORDS.has(k));

  if (!normalizedKeywords.length) return [];

  const results = [];
  const MAX_RESULTS = 60;
  const MAX_DEPTH = 4;

  async function searchDir(dir, depth) {
    if (depth > MAX_DEPTH || results.length >= MAX_RESULTS) return;

    let entries;
    try {
      entries = await fs.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      if (results.length >= MAX_RESULTS) break;

      const fullPath = path.join(dir, entry.name);
      const resolved = path.resolve(fullPath);

      if (excludeSet.has(resolved)) continue;
      if (entry.name.startsWith('.')) continue;

      if (entry.isDirectory()) {
        if (isIgnored(entry.name, true)) continue;
        const dirLower = entry.name.toLowerCase();
        const dirMatches = normalizedKeywords.some((k) => dirLower.includes(k));
        if (dirMatches || depth < 2) {
          await searchDir(fullPath, depth + 1);
        }
        continue;
      }

      if (!entry.isFile()) continue;
      if (isIgnored(entry.name, false)) continue;

      const nameLower = entry.name.toLowerCase();
      const stem = path.basename(entry.name, path.extname(entry.name)).toLowerCase();
      const parentName = path.basename(dir).toLowerCase();

      let relevance = 0;
      for (const kw of normalizedKeywords) {
        if (stem === kw) relevance += 5;
        else if (stem.includes(kw)) relevance += 3;
        else if (nameLower.includes(kw)) relevance += 2;
        if (parentName.includes(kw)) relevance += 1;
      }

      if (relevance > 0) {
        try {
          const stat = await fs.stat(fullPath);
          const record = buildFileRecord(resolved, stat, path.basename(dir));
          record.relevance = relevance;
          results.push(record);
        } catch {
          /* skip inaccessible */
        }
      }
    }
  }

  for (const dir of searchDirs) {
    if (results.length >= MAX_RESULTS) break;
    try {
      await fs.access(dir);
      await searchDir(dir, 0);
    } catch {
      /* dir may not exist */
    }
  }

  return results.sort((a, b) => b.relevance - a.relevance);
}

/* Hunter v2: query-based search + relocate. Generalized filesystem search
   used by the rebuilt Hunter panel and by FileHawk's "relocate" repair. */
async function huntFiles(opts = {}) {
  const {
    query = '',
    keywords = [],
    types = null,
    excludePaths = [],
    customDirs = [],
    limit = 80,
    exactName = false,
  } = opts;

  const searchDirs = customDirs.length ? customDirs : hunterDefaultDirs();
  const excludeSet = new Set(excludePaths.map((p) => path.resolve(p)));
  const typeSet = Array.isArray(types) && types.length ? new Set(types) : null;

  const queryTerms = String(query || '')
    .toLowerCase()
    .split(/[^a-z0-9]+/g)
    .filter((t) => t.length > 1);
  const kwTerms = (keywords || [])
    .map((k) => String(k).toLowerCase())
    .filter((k) => k.length > 2 && !TOKEN_STOPWORDS.has(k));

  if (!queryTerms.length && !kwTerms.length && !exactName) return [];

  const wantStem = exactName
    ? path.basename(String(query), path.extname(String(query))).toLowerCase()
    : '';
  const wantName = exactName ? String(query).toLowerCase() : '';

  const results = [];
  const HARD_CAP = 400;
  const MAX_DEPTH = 5;

  async function walk(dir, depth) {
    if (depth > MAX_DEPTH || results.length >= HARD_CAP) return;

    let entries;
    try {
      entries = await fs.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      if (results.length >= HARD_CAP) break;
      const full = path.join(dir, entry.name);
      const resolved = path.resolve(full);
      if (excludeSet.has(resolved)) continue;
      if (entry.name.startsWith('.')) continue;

      if (entry.isDirectory()) {
        if (isIgnored(entry.name, true)) continue;
        const dl = entry.name.toLowerCase();
        const dirMatches =
          queryTerms.some((t) => dl.includes(t)) || kwTerms.some((k) => dl.includes(k));
        if (dirMatches || depth < 2 || (exactName && depth < 4)) {
          await walk(full, depth + 1);
        }
        continue;
      }

      if (!entry.isFile()) continue;
      if (isIgnored(entry.name, false)) continue;

      const ext = path.extname(entry.name).slice(1).toLowerCase();
      const typeGroup = typeGroupFromExt(ext);
      if (typeSet && !typeSet.has(typeGroup)) continue;

      const nameLower = entry.name.toLowerCase();
      const stem = path.basename(entry.name, path.extname(entry.name)).toLowerCase();
      const parentName = path.basename(dir).toLowerCase();

      let relevance = 0;

      if (exactName) {
        if (nameLower === wantName) relevance += 100;
        else if (stem === wantStem) relevance += 60;
        else if (wantStem && stem.includes(wantStem)) relevance += 20;
      }
      for (const t of queryTerms) {
        if (stem === t) relevance += 8;
        else if (stem.includes(t)) relevance += 5;
        else if (nameLower.includes(t)) relevance += 3;
        if (parentName.includes(t)) relevance += 1;
      }
      for (const k of kwTerms) {
        if (stem === k) relevance += 4;
        else if (stem.includes(k)) relevance += 2;
        else if (nameLower.includes(k)) relevance += 1;
        if (parentName.includes(k)) relevance += 1;
      }

      if (relevance > 0) {
        try {
          const stat = await fs.stat(full);
          const record = buildFileRecord(resolved, stat, path.basename(dir));
          record.relevance = relevance;
          results.push(record);
        } catch {
          /* skip inaccessible */
        }
      }
    }
  }

  for (const dir of searchDirs) {
    if (results.length >= HARD_CAP) break;
    try {
      await fs.access(dir);
      await walk(dir, 0);
    } catch {
      /* dir may not exist */
    }
  }

  results.sort(
    (a, b) => b.relevance - a.relevance || String(b.modifiedAt).localeCompare(String(a.modifiedAt)),
  );
  return results.slice(0, limit);
}

// ── FileHawk ────────────────────────────────────────────────────────

async function filehawkCheck(filePaths = []) {
  const results = [];

  for (const filePath of filePaths) {
    try {
      const stat = await fs.stat(filePath);
      results.push({
        path: filePath,
        exists: true,
        size: stat.size,
        modifiedAt: stat.mtime.toISOString(),
      });
    } catch {
      results.push({ path: filePath, exists: false });
    }
  }

  return results;
}

function filehawkLocate(name, excludePaths, dirs) {
  return huntFiles({
    query: name,
    exactName: true,
    excludePaths: excludePaths || [],
    customDirs: dirs || [],
    limit: 40,
  });
}

// ── File Consolidation ──────────────────────────────────────────────

async function consolidateProject(projectName, filePaths = []) {
  const safeName = String(projectName || 'Untitled')
    .replace(/[<>:"/\\|?*]+/g, '_')
    .trim();
  const targetDir = path.join(
    os.homedir(),
    'Documents',
    'briizos',
    'forest-projects',
    safeName,
  );

  await fs.mkdir(targetDir, { recursive: true });

  const result = { copied: 0, skipped: 0, failed: 0, targetDir };

  for (const src of filePaths) {
    const dest = path.join(targetDir, path.basename(src));
    try {
      try {
        await fs.access(dest);
        result.skipped += 1;
        continue;
      } catch {
        /* doesn't exist yet — proceed */
      }
      await fs.copyFile(src, dest);
      result.copied += 1;
    } catch {
      result.failed += 1;
    }
  }

  return result;
}

module.exports = {
  loadState,
  saveState,
  importDroppedPaths,
  hunterDefaultDirs,
  hunterSearch,
  huntFiles,
  filehawkCheck,
  filehawkLocate,
  consolidateProject,
};
