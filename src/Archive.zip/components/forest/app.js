import { lockDragSelection } from '../../lib/dragSelection';
import logger from '../../lib/logger';

// A reopened board must read after the previous instance's final save.
let pendingSaves = Promise.resolve();

// Each mount owns its DOM references, listeners, and state. A classic script
// cannot be reinjected safely: its top-level lexical declarations survive removal.
export function mountForest(host) {
let destroyed = false;
let loaded = false;
const forestShell = host.querySelector('.forest-shell');

function dispatchForestLog(level, message, data) {
  const log = logger[level] || logger.info;
  log('forest', message, data);
}
const stage = host.querySelector('#forest-stage');
const world = host.querySelector('#forest-world');
const grid = host.querySelector('#forest-grid');
const dropOverlay = host.querySelector('#forest-dropOverlay');
const emptyState = host.querySelector('#forest-emptyState');
const searchInput = host.querySelector('#forest-searchInput');
const collapseAllBtn = host.querySelector('#forest-collapseAllBtn');
const resetViewBtn = host.querySelector('#forest-resetViewBtn');
const fitBtn = host.querySelector('#forest-fitBtn');
const projectCountEl = host.querySelector('#forest-projectCount');
const fileCountEl = host.querySelector('#forest-fileCount');
const zoomReadoutEl = host.querySelector('#forest-zoomReadout');
const saveStateEl = host.querySelector('#forest-saveState');
const tagStrip = host.querySelector('#forest-tagStrip');
const projectViewer = host.querySelector('#forest-projectViewer');
const hunterPanel = host.querySelector('#forest-hunterPanel');
const filehawkPanel = host.querySelector('#forest-filehawkPanel');
const filehawkBtn = host.querySelector('#forest-filehawkBtn');
const sortActivityBtn = host.querySelector('#forest-sortActivityBtn');
const dimToggle = host.querySelector('#forest-dimToggle');



const ACCENTS = [
  { hex: '#16C784', rgb: '22,199,132' },  // emerald gemlight
  { hex: '#3D7BE8', rgb: '61,123,232' },  // cobalt river
  { hex: '#A2B84F', rgb: '162,184,79' },  // sunlit moss
  { hex: '#8B7AD9', rgb: '139,122,217' }, // dusk violet
  { hex: '#E0A352', rgb: '224,163,82' },  // amber path
  { hex: '#56A0E8', rgb: '86,160,232' },  // shallow river
  { hex: '#2E9E8F', rgb: '46,158,143' },  // pine teal
  { hex: '#D4939F', rgb: '212,147,159' }, // alpenglow rose
];

const TYPE_ORDER = [
  'design',
  'image',
  'video',
  'audio',
  'pdf',
  'document',
  'spreadsheet',
  'slides',
  'code',
  'data',
  'archive',
  'model',
  'other',
];

const TYPE_LABELS = {
  image: 'Images',
  video: 'Videos',
  audio: 'Audio',
  pdf: 'PDFs',
  document: 'Documents',
  spreadsheet: 'Sheets',
  slides: 'Slides',
  design: 'Design',
  code: 'Code',
  data: 'Data',
  archive: 'Archives',
  model: '3D',
  other: 'Files',
};

const state = {
  viewport: { x: 260, y: 160, scale: 1 },
  projects: [],
  query: '',
  selectedProjectId: null,
  viewerProjectId: null,
  projectTabs: {},
  hunterProjectId: null,
  hunterResults: [],
  hunterLoading: false,
  hunterDirs: [],
  hunterQueryStr: '',          // Hunter manual search query
  hunterTypes: new Set(),      // active type filters
  hunterSelected: new Set(),   // selected result paths (multi-add)
  hunterRelocate: null,        // { fileId, fileName } when relocating a missing file
  // FileHawk panel
  filehawkOpen: false,
  filehawkStatus: {},          // file.path -> 'ok' | 'modified' | 'missing'
  filehawkScanAt: null,
  filehawkScanning: false,
  sortByActivity: false,
  viewerActiveModal: null,
  viewerTagFilter: new Set(),
  viewerDrag: null,
  // Timeline state
  tlZoom: 1,           // zoom level 1=years, 2=months, 3=weeks
  tlViewport: { start: null, end: null },  // visible date range
  tlGhost: null,        // { x, date, snappedDate } for ghost node
  tlPending: null,      // { date } waiting for second click
  tlHoverDate: null,    // current hovered date
  tlPan: null,          // { startX, startViewport }
  tlAddMode: false,     // timeline "add milestone" mode toggle; off = hovering does nothing
};

let interaction = null;
let saveTimer = null;
let lastSaveErrorMessage = null;
let dragDepth = 0;
let filehawkTimer = null;
const PROJECT_CARD_WIDTH = 360;

function uid() {
  return globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function updateZoomLevelFromViewport() {
  if (!state.tlViewport.start || !state.tlViewport.end) return;
  const totalMs = state.tlViewport.end.getTime() - state.tlViewport.start.getTime();
  const days = totalMs / (1000 * 60 * 60 * 24);
  if (days > 180) state.tlZoom = 1;
  else if (days > 14) state.tlZoom = 2;
  else if (days > 2) state.tlZoom = 3;
  else state.tlZoom = 4;
}

function zoomToFit(project) {
  const milestones = project.milestones || [];
  if (milestones.length === 0) return;

  const dates = milestones.map(m => new Date(m.date + 'T00:00:00').getTime()).sort((a, b) => a - b);
  const minDate = dates[0];
  const maxDate = dates[dates.length - 1];
  
  const count = milestones.length;
  let range = maxDate - minDate;
  
  let start, end;
  if (count === 1) {
    const oneMonth = 1000 * 60 * 60 * 24 * 30;
    start = minDate - oneMonth / 2;
    end = minDate + oneMonth / 2;
  } else if (count < 5) {
    // Fill the frame: set range such that milestones have generous space
    // but are clearly visible.
    const padding = range * 0.5; // 50% padding for small counts
    start = minDate - padding;
    end = maxDate + padding;
    
    // Ensure at least 2 weeks range
    const minRange = 1000 * 60 * 60 * 24 * 14;
    if (end - start < minRange) {
      const center = (minDate + maxDate) / 2;
      start = center - minRange / 2;
      end = center + minRange / 2;
    }
  } else {
    // Standard fit with 10% padding
    const padding = range * 0.1;
    start = minDate - padding;
    end = maxDate + padding;
  }

  state.tlViewport = { start: new Date(start), end: new Date(end) };
  updateZoomLevelFromViewport();
  refreshViewer();
}

function jumpToNextNode(project) {
  const milestones = project.milestones || [];
  if (milestones.length === 0) return;
  
  if (!state.tlViewport.start || !state.tlViewport.end) {
    initTimelineViewport(project);
  }

  const sorted = [...milestones].sort((a, b) => a.date.localeCompare(b.date));
  const viewportCenterMs = (state.tlViewport.start.getTime() + state.tlViewport.end.getTime()) / 2;
  
  let next = sorted.find(m => new Date(m.date + 'T00:00:00').getTime() > viewportCenterMs + 10000); // 10s buffer
  if (!next) next = sorted[0];
  
  const targetMs = new Date(next.date + 'T00:00:00').getTime();
  const range = state.tlViewport.end.getTime() - state.tlViewport.start.getTime();
  
  state.tlViewport = {
    start: new Date(targetMs - range / 2),
    end: new Date(targetMs + range / 2)
  };
  refreshViewer();
}

function positiveMod(value, modulus) {
  if (!modulus) return 0;
  return ((value % modulus) + modulus) % modulus;
}

function normalizeText(value) {
  return String(value ?? '').trim().toLowerCase();
}

function cleanTag(value) {
  return normalizeText(value)
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9._-]/g, '')
    .slice(0, 32);
}

function dedupe(values = []) {
  return [...new Set(values.filter(Boolean))];
}

function hashString(value) {
  let hash = 2166136261;
  const input = String(value ?? '');
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function accentForSeed(seed) {
  return ACCENTS[hashString(seed) % ACCENTS.length];
}

// Projects persist their accent, so anything saved under an older palette
// (pre-forest purples/golds) gets remapped to the nearest current accent.
const LEGACY_ACCENTS = {
  '#7C3AED': ACCENTS[0], // purple → emerald gemlight
  '#8B5CF6': ACCENTS[3], // violet → dusk violet
  '#9F7AEA': ACCENTS[3],
  '#38BDF8': ACCENTS[5], // sky → shallow river
  '#22C55E': ACCENTS[0],
  '#2F8F5B': ACCENTS[0],
  '#6BA368': ACCENTS[2], // moss → sunlit moss
  '#14B8A6': ACCENTS[6], // teal → pine teal
  '#F97316': ACCENTS[4], // orange → amber path
  '#EAB308': ACCENTS[4],
  '#C08A28': ACCENTS[4],
  '#B8763A': ACCENTS[4],
  '#7A4A24': ACCENTS[4],
  '#EC4899': ACCENTS[7], // pink → alpenglow rose
};

function migrateAccent(accent) {
  const legacy = LEGACY_ACCENTS[(accent.hex || '').toUpperCase()];
  return legacy || accent;
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (match) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[match]
  ));
}

function escapeAttr(value = '') {
  return escapeHtml(value);
}

function formatBytes(bytes = 0) {
  const value = Number(bytes) || 0;
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = value;
  let unitIndex = 0;

  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex += 1;
  }

  const precision = size >= 10 || unitIndex === 0 ? 0 : 1;
  return `${size.toFixed(precision)} ${units[unitIndex]}`;
}

function relativeDate(input) {
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) return 'Unknown date';

  const diff = Date.now() - date.getTime();
  const day = 86400000;

  if (diff < day) return 'Today';
  if (diff < day * 2) return 'Yesterday';
  if (diff < day * 30) return `${Math.round(diff / day)}d ago`;

  return date.toLocaleDateString();
}

function toFileUrl(filePath = '') {
  let value = String(filePath).replace(/\\/g, '/');
  if (!value.startsWith('/')) value = `/${value}`;
  return encodeURI(`file://${value}`);
}

function readableGroup(group) {
  return TYPE_LABELS[group] || 'Files';
}

const VIDEO_EXTS = new Set(['mp4', 'mov', 'm4v', 'webm']);
const AUDIO_EXTS = new Set(['mp3', 'wav', 'aiff', 'aac', 'ogg', 'm4a', 'flac']);

function isVideoFile(file) {
  return VIDEO_EXTS.has((file.ext || '').toLowerCase());
}

function isAudioFile(file) {
  return AUDIO_EXTS.has((file.ext || '').toLowerCase());
}

function renderPreviewMedia(file, className, extraAttrs = '') {
  const src = escapeAttr(toFileUrl(file.path));
  if (isVideoFile(file)) {
    return `<video class="${className}" src="${src}" muted playsinline preload="metadata" ${extraAttrs}></video>`;
  }
  if (isAudioFile(file)) {
    return `<div class="${className} audio-preview" ${extraAttrs}>
      <div class="audio-preview-icon">♫</div>
      <div class="audio-preview-name">${escapeHtml(file.name)}</div>
      <audio src="${src}" preload="metadata"></audio>
    </div>`;
  }
  return `<img class="${className}" src="${src}" alt="${escapeAttr(file.name)}" loading="lazy" ${extraAttrs} />`;
}

function fileBadgeLabel(file) {
  const ext = (file.ext || '').toUpperCase();
  if (ext && ext.length <= 5) return ext;

  const labels = {
    image: 'IMG',
    video: 'VID',
    audio: 'AUD',
    pdf: 'PDF',
    document: 'DOC',
    spreadsheet: 'XLS',
    slides: 'PPT',
    design: 'DES',
    code: 'CODE',
    data: 'DATA',
    archive: 'ZIP',
    model: '3D',
    other: 'FILE',
  };

  return labels[file.typeGroup] || 'FILE';
}

function sortFiles(a, b) {
  const aIndex = TYPE_ORDER.indexOf(a.typeGroup);
  const bIndex = TYPE_ORDER.indexOf(b.typeGroup);

  const typeCompare = (aIndex === -1 ? 999 : aIndex) - (bIndex === -1 ? 999 : bIndex);
  if (typeCompare !== 0) return typeCompare;

  return a.name.localeCompare(b.name);
}

function normalizeFile(file = {}) {
  const ext = normalizeText(file.ext || (file.name?.split('.').pop() ?? '')).replace(/^\./, '');

  return {
    id: file.id || uid(),
    name: file.name || 'Untitled',
    path: file.path || '',
    ext,
    size: Number(file.size || 0),
    modifiedAt: file.modifiedAt || new Date().toISOString(),
    typeGroup: file.typeGroup || 'other',
    previewable: Boolean(file.previewable),
    filehawk: file.filehawk === true,
    tags: dedupe((file.tags || []).map(cleanTag)),
  };
}

function normalizeProject(project = {}) {
  const x = Number(project.x);
  const y = Number(project.y);

  const accent = migrateAccent(project.accent && project.accentRgb
    ? { hex: project.accent, rgb: project.accentRgb }
    : accentForSeed(project.name || project.id || uid()));

  const files = (project.files || []).map(normalizeFile).sort(sortFiles);

  const milestones = (project.milestones || []).map((m) => ({
    id: m.id || uid(),
    label: m.label || 'Milestone',
    date: m.date || new Date().toISOString().slice(0, 10),
    completed: Boolean(m.completed),
    description: m.description || '',
    estimatedDays: Number(m.estimatedDays) || 0,
    fileIds: Array.isArray(m.fileIds) ? m.fileIds : [],
    subtasks: (m.subtasks || []).map((s) => ({
      id: s.id || uid(),
      text: s.text || '',
      done: Boolean(s.done),
    })),
  }));

  return {
    id: project.id || uid(),
    name: project.name || 'Untitled Project',
    x: Number.isFinite(x) ? x : 0,
    y: Number.isFinite(y) ? y : 0,
    expanded: Boolean(project.expanded),
    tags: dedupe((project.tags || []).map(cleanTag)),
    accent: accent.hex,
    accentRgb: accent.rgb,
    createdAt: project.createdAt || new Date().toISOString(),
    files,
    milestones,
    consolidated: Boolean(project.consolidated),
    coverFileId: project.coverFileId || null,
    coverPosition: project.coverPosition || '50% 50%',
    deadline: typeof project.deadline === 'string' ? project.deadline : '',
    importance: Number.isInteger(project.importance) && project.importance >= 1 && project.importance <= 10
      ? project.importance
      : null,
    size: project.size !== null && project.size !== undefined && project.size !== ''
      && Number.isFinite(Number(project.size)) && Number(project.size) >= 0
      ? Number(project.size)
      : null,
    relevance: typeof project.relevance === 'string' ? project.relevance : '',
  };
}

function serializeState() {
  return {
    version: 1,
    viewport: { ...state.viewport },
    hunterDirs: [...state.hunterDirs],
    projects: state.projects.map((project) => ({
      ...project,
      files: project.files.map((file) => ({ ...file })),
      tags: [...project.tags],
      milestones: (project.milestones || []).map((m) => ({
        ...m,
        fileIds: [...(m.fileIds || [])],
        subtasks: (m.subtasks || []).map((s) => ({ ...s })),
      })),
    })),
  };
}

function setSaveStatus(text) {
  saveStateEl.textContent = text;
}

function scheduleSave(immediate = false) {
  if (destroyed || !loaded) return;
  clearTimeout(saveTimer);
  setSaveStatus('Saving…');
  saveTimer = setTimeout(saveNow, immediate ? 60 : 550);
}

async function saveNow() {
  saveTimer = null;
  const snapshot = serializeState();
  const saving = pendingSaves.then(() => window.api.forestSaveState(snapshot));
  pendingSaves = saving.catch(() => {});
  try {
    await saving;
    lastSaveErrorMessage = null;
    if (!destroyed) setSaveStatus(`Saved ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
    dispatchForestLog('debug', 'Board state saved', { projectCount: snapshot.projects.length });
  } catch (error) {
    console.error(error);
    const message = error?.message || 'Unknown error';
    const rejected = /INVALID_INPUT|too large|too long|max \d|must be/i.test(message);
    if (!destroyed) setSaveStatus(rejected ? 'Save rejected — board exceeds size limits' : 'Save failed');
    // Log each distinct failure once at error level; identical repeats
    // (autosaves of the same unsaveable state) drop to debug so the
    // error log doesn't flood.
    if (message !== lastSaveErrorMessage) {
      lastSaveErrorMessage = message;
      dispatchForestLog('error', rejected ? 'Board save rejected by validation' : 'Board save failed', message);
    } else {
      dispatchForestLog('debug', 'Board save still failing', message);
    }
  }
}

function getProject(projectId) {
  return state.projects.find((project) => project.id === projectId) || null;
}

function getFile(projectId, fileId) {
  const project = getProject(projectId);
  if (!project) return null;
  return project.files.find((file) => file.id === fileId) || null;
}

function parseQuery(query = '') {
  const raw = String(query).toLowerCase();
  const tags = [...raw.matchAll(/#([a-z0-9._-]+)/g)].map((match) => match[1]);
  const terms = raw.replace(/#[a-z0-9._-]+/g, ' ').split(/\s+/).filter(Boolean);
  return { tags, terms };
}

function projectMatches(project) {
  const { tags, terms } = parseQuery(state.query);
  if (!tags.length && !terms.length) return true;

  const tagSet = new Set([
    ...project.tags,
    ...project.files.flatMap((file) => file.tags || []),
  ].map(normalizeText));

  const text = [
    project.name,
    ...project.tags,
    ...project.files.flatMap((file) => [file.name, ...(file.tags || [])]),
  ].join(' ').toLowerCase();

  return tags.every((tag) => tagSet.has(tag) || text.includes(tag))
    && terms.every((term) => text.includes(term));
}

function getVisibleProjects() {
  const filtered = state.projects.filter(projectMatches);
  if (state.sortByActivity) {
    filtered.sort((a, b) => {
      const aNewest = a.files.length ? Math.max(...a.files.map((f) => new Date(f.modifiedAt).getTime())) : 0;
      const bNewest = b.files.length ? Math.max(...b.files.map((f) => new Date(f.modifiedAt).getTime())) : 0;
      return bNewest - aNewest;
    });
  }
  return filtered;
}

function topGroups(project, limit = 2) {
  const counts = new Map();

  project.files.forEach((file) => {
    counts.set(file.typeGroup, (counts.get(file.typeGroup) || 0) + 1);
  });

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([group, count]) => `${readableGroup(group)} ${count}`)
    .join(' • ');
}

function renderPreviewGrid(project) {
  // Visual files (images/video) live only in this gallery — not in the file list.
  const previewFiles = project.files.filter((file) => file.previewable && !isAudioFile(file));

  if (previewFiles.length) {
    const count = previewFiles.length;
    const layoutClass = count === 1 ? 'preview-grid--solo' : count === 2 ? 'preview-grid--duo' : '';

    const items = previewFiles.map((file) => {
      const isCover = project.coverFileId === file.id;
      return `
      <div class="preview-thumb ${isCover ? 'is-cover' : ''}" data-file-id="${file.id}">
        ${renderPreviewMedia(file, 'preview-thumb-media')}
        <div class="preview-thumb-actions">
          <button class="thumb-btn cover-btn ${isCover ? 'forest-active' : ''}" data-action="set-cover" data-project-id="${project.id}" data-file-id="${file.id}" title="${isCover ? 'Current cover' : 'Set as cover'}">⊞</button>
          <button class="thumb-btn open-btn" data-action="open-file" data-project-id="${project.id}" data-file-id="${file.id}" title="Open file">↗</button>
        </div>
      </div>
    `;
    }).join('');

    return `<div class="preview-grid ${layoutClass}">${items}</div>`;
  }

  const groups = [...new Set(project.files.map((file) => readableGroup(file.typeGroup)))].slice(0, 3);

  if (!groups.length) {
    return `<div class="preview-grid forest-empty"><div class="preview-type-pill">No files yet</div></div>`;
  }

  return `
    <div class="preview-grid forest-empty">
      ${groups.map((group) => `<div class="preview-type-pill">${escapeHtml(group)}</div>`).join('')}
    </div>
  `;
}

function renderFileRow(projectId, file, isCover = false) {
  const meta = [
    file.ext ? file.ext.toUpperCase() : 'FILE',
    formatBytes(file.size),
    relativeDate(file.modifiedAt),
  ].join(' • ');

  return `
    <div class="file-row ${isCover ? 'is-cover' : ''}" data-action="open-file" data-project-id="${projectId}" data-file-id="${file.id}" title="${escapeAttr(file.path)}">
      <div class="file-badge">${escapeHtml(fileBadgeLabel(file))}</div>
      <div class="file-copy">
        <div class="forest-file-name">${escapeHtml(file.name)}</div>
        <div class="file-sub">${escapeHtml(meta)}</div>
      </div>
      ${file.previewable && !isAudioFile(file) ? `<button class="tiny-btn cover-btn ${isCover ? 'forest-active' : ''}" data-action="set-cover" data-project-id="${projectId}" data-file-id="${file.id}" title="${isCover ? 'Current cover' : 'Set as cover'}">⊞</button>` : ''}
      <button class="tiny-btn" data-action="show-file" data-project-id="${projectId}" data-file-id="${file.id}" title="Reveal in folder">↗</button>
    </div>
  `;
}

function renderProject(project) {
  const shownTags = project.tags.slice(0, project.expanded ? 18 : 8);
  const moreTags = !project.expanded && project.tags.length > 8 ? project.tags.length - 8 : 0;
  const summary = topGroups(project);
  const coverFile = project.coverFileId ? project.files.find((f) => f.id === project.coverFileId) : null;
  const hasCover = coverFile && coverFile.previewable;

  return `
    <article
      class="project-card ${project.expanded ? 'expanded' : ''} ${state.selectedProjectId === project.id ? 'forest-selected' : ''} ${hasCover ? 'has-cover' : ''}"
      data-id="${project.id}"
      style="left:${project.x}px; top:${project.y}px; --accent:${project.accent}; --accent-rgb:${project.accentRgb};"
    >
      <div class="project-accent"></div>

      ${hasCover ? `
        <div class="project-cover" data-role="cover-drag-area">
          ${renderPreviewMedia(coverFile, 'project-cover-img', `style="object-position:${project.coverPosition}"`)}
          <div class="project-cover-fade"></div>
        </div>
      ` : ''}

      <div class="project-header" data-drag-handle>
        <div class="project-emblem">${escapeHtml((project.name || 'P').trim().slice(0, 1).toUpperCase())}</div>

        <div class="project-heading">
          <span
            class="project-title-label"
            data-role="project-title"
          >${escapeHtml(project.name)}</span>
          <div class="project-meta">
            ${project.files.length} file${project.files.length === 1 ? '' : 's'}${summary ? ` • ${escapeHtml(summary)}` : ''}
          </div>
        </div>

        <div class="project-controls">
          <button class="icon-btn" data-action="open-viewer" title="Open Project Viewer">⊞</button>
          <button class="icon-btn" data-action="toggle-expand" title="${project.expanded ? 'Collapse project' : 'Expand project'}">${project.expanded ? '–' : '+'}</button>
        </div>
      </div>

      ${hasCover ? '' : `
        <div class="project-tags">
          ${shownTags.map((tag) => `
            <span class="tag-chip-wrap">
              <button
                class="tag-chip"
                data-action="tag-filter"
                data-tag="${escapeAttr(tag)}"
                title="Click to filter • Double-click to edit"
              >#${escapeHtml(tag)}</button>${project.expanded ? `<button
                class="tag-x"
                data-action="delete-tag"
                data-tag="${escapeAttr(tag)}"
                title="Remove tag"
              >×</button>` : ''}
            </span>
          `).join('')}
          ${moreTags ? `<span class="tag-fade">+${moreTags}</span>` : ''}
        </div>
      `}

      ${project.expanded ? `
        <div class="project-body">
          ${hasCover ? `
            <div class="project-tags">
              ${shownTags.map((tag) => `
                <span class="tag-chip-wrap">
                  <button class="tag-chip" data-action="tag-filter" data-tag="${escapeAttr(tag)}" title="Click to filter • Double-click to edit">#${escapeHtml(tag)}</button>
                  <button class="tag-x" data-action="delete-tag" data-tag="${escapeAttr(tag)}" title="Remove tag">×</button>
                </span>
              `).join('')}
            </div>
          ` : ''}

          <div class="tag-editor">
            <input class="tag-input" data-role="tag-input" autocomplete="off" placeholder="Add a tag and press Enter" />
          </div>

          <div class="project-actions">
            <button class="forest-action-btn" data-action="open-viewer" title="Full-screen project view with timeline">⊞ Viewer</button>
            <button class="forest-action-btn" data-action="hunter-search" title="Search filesystem for related files">⌕ Hunter</button>
            <button class="forest-action-btn" data-action="consolidate" title="Copy files to ~/Documents/projungle/projects/${escapeAttr(project.name)}">⤓ Consolidate</button>
            ${hasCover ? '<button class="forest-action-btn" data-action="remove-cover" title="Remove cover image">✕ Cover</button>' : ''}
          </div>

          ${renderActivityBadge(project)}

          <div class="forest-project-tabs" role="group" aria-label="Project files">
            <button class="forest-action-btn" data-action="project-files-tab" data-tab="files" aria-pressed="${state.projectTabs[project.id] !== 'filehawk'}">Files</button>
            <button class="forest-action-btn" data-action="project-files-tab" data-tab="filehawk" aria-pressed="${state.projectTabs[project.id] === 'filehawk'}">FileHawk suggestions</button>
          </div>
          ${state.projectTabs[project.id] === 'filehawk' ? renderWatchSuggestions(project) : renderPreviewGrid(project)}

          ${(() => {
            if (state.projectTabs[project.id] === 'filehawk') return '';
            // Images/video are shown in the gallery above; the list holds the rest.
            const listFiles = project.files.filter((file) => !(file.previewable && !isAudioFile(file)));
            if (project.files.length === 0) {
              return '<div class="file-list"><div class="no-files">Drop files on this card to add them here.</div></div>';
            }
            if (!listFiles.length) return '';
            return `<div class="file-list">${listFiles.map((file) => renderFileRow(project.id, file, hasCover && file.id === project.coverFileId)).join('')}</div>`;
          })()}
        </div>
      ` : ''}
    </article>
  `;
}

function renderWatchSuggestions(project) {
  return `<div class="file-list forest-watch-suggestions">
    <p>Choose which project files FileHawk should watch for changes or missing paths.</p>
    ${project.files.map(file => `<div class="file-row">
      <span class="file-copy">${escapeHtml(file.name)}</span>
      <div class="interface-choices" role="group" aria-label="FileHawk monitoring">
        <button class="forest-action-btn" data-action="filehawk-designate" data-file-id="${escapeAttr(file.id)}" data-watch="false" aria-pressed="${!file.filehawk}">Unwatched</button>
        <button class="forest-action-btn" data-action="filehawk-designate" data-file-id="${escapeAttr(file.id)}" data-watch="true" aria-pressed="${file.filehawk}">Watching</button>
      </div>
    </div>`).join('') || '<p>Add files to this project to choose what to watch.</p>'}
  </div>`;
}

function designateFile(project, fileId, watch) {
  const file = project?.files.find(f => f.id === fileId);
  if (!file) return;
  file.filehawk = watch;
  delete state.filehawkStatus[file.path];
  dispatchForestLog('info', watch ? 'File designated for FileHawk' : 'FileHawk monitoring removed; project file retained', { projectId: project.id, file: file.name });
  scheduleSave(true);
  render();
  if (state.filehawkOpen) renderFilehawkPanel();
  if (watch) filehawkScan();
}

/* ── FileHawk: activity badge ───────────────────────────────────────── */

function projectActivityLevel(project) {
  if (!project.files.length) return 'idle';
  const now = Date.now();
  const newest = Math.max(...project.files.map((f) => new Date(f.modifiedAt).getTime()));
  const hoursAgo = (now - newest) / 3600000;
  if (hoursAgo < 24) return 'forest-active';
  if (hoursAgo < 24 * 7) return 'recent';
  if (hoursAgo < 24 * 30) return 'moderate';
  return 'stale';
}

function activityLabel(level) {
  return { active: 'Active today', recent: 'This week', moderate: 'This month', stale: 'Inactive', idle: 'No files' }[level] || '';
}

function renderActivityBadge(project) {
  const level = projectActivityLevel(project);
  return `<div class="activity-badge activity-${level}" title="FileHawk: ${activityLabel(level)}">
    <span class="activity-dot"></span> ${activityLabel(level)}
  </div>`;
}

/* ── Project progress from milestones ──────────────────────────────── */

function projectProgress(project) {
  const ms = project.milestones || [];
  if (!ms.length) return -1;
  const done = ms.filter((m) => m.completed).length;
  return Math.round((done / ms.length) * 100);
}

/* ── Project Viewer ────────────────────────────────────────────────── */

function formatMilestoneDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatTimelineDate(date, zoom) {
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return '';
  if (zoom <= 1) {
    return d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  }
  if (zoom <= 2) {
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  }
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

function initTimelineViewport(project) {
  const milestones = project.milestones || [];
  
  if (milestones.length === 0) {
    const twoYearsMs = 1000 * 60 * 60 * 24 * 365 * 2;
    const now = new Date();
    const start = new Date(now.getTime() - twoYearsMs / 2);
    const end = new Date(now.getTime() + twoYearsMs / 2);
    state.tlViewport = { start, end };
    state.tlZoom = 1;
    return;
  }
  
  // Use the same logic as zoomToFit but don't call refreshViewer since this is usually called during render/init
  const dates = milestones.map(m => new Date(m.date + 'T00:00:00').getTime()).sort((a, b) => a - b);
  const minDate = dates[0];
  const maxDate = dates[dates.length - 1];
  const count = milestones.length;
  const range = maxDate - minDate;
  
  let start, end;
  if (count === 1) {
    const oneMonth = 1000 * 60 * 60 * 24 * 30;
    start = minDate - oneMonth / 2;
    end = minDate + oneMonth / 2;
  } else if (count < 5) {
    const padding = range * 0.5;
    start = minDate - padding;
    end = maxDate + padding;
    const minRange = 1000 * 60 * 60 * 24 * 14;
    if (end - start < minRange) {
      const center = (minDate + maxDate) / 2;
      start = center - minRange / 2;
      end = center + minRange / 2;
    }
  } else {
    const padding = range * 0.1;
    start = minDate - padding;
    end = maxDate + padding;
  }

  state.tlViewport = { start: new Date(start), end: new Date(end) };
  updateZoomLevelFromViewport();
}

function dateToX(date, trackWidth, viewport) {
  if (!viewport.start || !viewport.end) return 0;
  const totalMs = viewport.end.getTime() - viewport.start.getTime();
  if (totalMs <= 0) return 0;
  const dateMs = date.getTime() - viewport.start.getTime();
  return (dateMs / totalMs) * trackWidth;
}

function xToDate(x, trackWidth, viewport) {
  if (!viewport.start || !viewport.end || trackWidth <= 0) return null;
  const totalMs = viewport.end.getTime() - viewport.start.getTime();
  const ms = (x / trackWidth) * totalMs;
  return new Date(viewport.start.getTime() + ms);
}

function snapDateToUnit(date, zoom) {
  const d = new Date(date);
  if (zoom >= 2) {
    d.setHours(0, 0, 0, 0);
    if (zoom >= 3) {
      return d;
    }
    const dayOfMonth = d.getDate();
    const midDay = 16;
    if (dayOfMonth > midDay) {
      d.setDate(midDay);
    } else {
      d.setDate(1);
    }
    return d;
  }
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  const month = d.getMonth();
  const midMonth = 15;
  if (month % 2 === 1) {
    d.setMonth(month - 1);
  } else if (month < 11) {
    d.setMonth(month + 1);
  }
  return d;
}

function getZoomPixelsPerMs(zoom, trackWidth) {
  const viewport = state.tlViewport;
  if (!viewport.start || !viewport.end) return 1;
  const totalMs = viewport.end.getTime() - viewport.start.getTime();
  return trackWidth / totalMs;
}

function canPlaceMilestone(zoom) {
  return zoom >= 2;
}

function renderMilestoneModal(milestone, project) {
  const subtasks = milestone.subtasks || [];
  const fileIds = new Set(milestone.fileIds || []);

  return `
    <div class="tl-modal" data-modal-id="${milestone.id}">
      <div class="tl-modal-arrow"></div>
      <div class="tl-modal-inner">
        <div class="tl-modal-header">
          <input class="tl-modal-title" value="${escapeAttr(milestone.label)}"
                 data-role="modal-milestone-label" data-milestone-id="${milestone.id}"
                 placeholder="Milestone name" spellcheck="false" autocomplete="off" />
          <div class="tl-modal-actions">
            <button class="tl-modal-toggle ${milestone.completed ? 'forest-completed' : ''}"
                    data-action="toggle-milestone" data-milestone-id="${milestone.id}"
                    title="${milestone.completed ? 'Mark incomplete' : 'Mark complete'}">
              ${milestone.completed ? '✓ Done' : '○ Todo'}
            </button>
            <button class="tl-modal-delete" data-action="delete-milestone" data-milestone-id="${milestone.id}" title="Delete milestone">
              <span class="jr-sf-symbol" aria-hidden="true">􀈑</span>
            </button>
            <button class="tl-modal-close" data-action="close-milestone-modal" title="Close (Esc)">✕</button>
          </div>
        </div>

        <div class="tl-modal-row">
          <label class="tl-modal-label">Due</label>
          <input type="date" class="tl-modal-date" value="${milestone.date}"
                 data-role="modal-milestone-date" data-milestone-id="${milestone.id}" />
        </div>

        <div class="tl-modal-row">
          <label class="tl-modal-label">Estimate</label>
          <div class="tl-modal-estimate">
            <input type="number" class="tl-modal-days" value="${milestone.estimatedDays || ''}"
                   data-role="modal-milestone-days" data-milestone-id="${milestone.id}"
                   placeholder="—" min="0" step="0.5" />
            <span class="tl-modal-days-unit">days</span>
          </div>
        </div>

        <div class="tl-modal-divider"></div>

        <div class="tl-modal-row tl-modal-row--col">
          <label class="tl-modal-label">Description</label>
          <textarea class="tl-modal-desc" rows="2" placeholder="What needs to happen…"
                    data-role="modal-milestone-desc" data-milestone-id="${milestone.id}"
          >${escapeHtml(milestone.description || '')}</textarea>
        </div>

        <div class="tl-modal-divider"></div>

        <div class="tl-modal-row tl-modal-row--col">
          <label class="tl-modal-label">Subtasks ${subtasks.length ? `<span class="tl-modal-count">${subtasks.filter((s) => s.done).length}/${subtasks.length}</span>` : ''}</label>
          <div class="tl-subtask-list">
            ${subtasks.map((s) => `
              <label class="tl-subtask ${s.done ? 'forest-done' : ''}">
                <input type="checkbox" ${s.done ? 'checked' : ''}
                       data-action="toggle-subtask" data-milestone-id="${milestone.id}" data-subtask-id="${s.id}" />
                <span class="tl-subtask-text">${escapeHtml(s.text)}</span>
                <button class="tl-subtask-delete" data-action="delete-subtask" data-milestone-id="${milestone.id}" data-subtask-id="${s.id}">×</button>
              </label>
            `).join('')}
          </div>
          <div class="tl-subtask-add">
            <input class="tl-subtask-input" placeholder="Add subtask…"
                   data-role="subtask-input" data-milestone-id="${milestone.id}" autocomplete="off" />
          </div>
        </div>

        <div class="tl-modal-divider"></div>

        <div class="tl-modal-row tl-modal-row--col">
          <label class="tl-modal-label">Linked Files <span class="tl-modal-count">${fileIds.size}</span></label>
          <div class="tl-file-picker">
            ${project.files.map((f) => `
              <label class="tl-file-option ${fileIds.has(f.id) ? 'linked' : ''}">
                <input type="checkbox" ${fileIds.has(f.id) ? 'checked' : ''}
                       data-action="toggle-file-link" data-milestone-id="${milestone.id}" data-file-id="${f.id}" />
                <span class="tl-file-badge">${escapeHtml(fileBadgeLabel(f))}</span>
                <span class="tl-file-name">${escapeHtml(f.name)}</span>
              </label>
            `).join('')}
            ${!project.files.length ? '<div class="tl-file-picker-empty">No files in project</div>' : ''}
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderMilestoneTimeline(project) {
  const milestones = project.milestones || [];
  const activeModalId = state.viewerActiveModal;
  const progress = projectProgress(project);
  const { tlZoom, tlViewport, tlGhost, tlPending } = state;

  if (!tlViewport.start || !tlViewport.end) {
    initTimelineViewport(project);
  }

  if (!milestones.length) {
    return `
      <div class="tl-empty">
        <div class="tl-empty-track">
          <div class="tl-empty-line"></div>
          <div class="tl-empty-line"></div>
        </div>
        <p class="tl-empty-hint">Turn on <strong>+ Add</strong> above, then click the track to place your first milestone</p>
      </div>
    `;
  }

  const sorted = [...milestones].sort((a, b) => a.date.localeCompare(b.date));
  const { start, end } = state.tlViewport;
  const totalMs = end.getTime() - start.getTime();

  const renderAxis = () => {
    const daysInRange = totalMs / (1000 * 60 * 60 * 24);
    const createTier = (className, opacity) => `<div class="${className}" style="opacity: ${opacity}">`;
    const label = (pct, text) => `<span class="tl-axis-label" style="left:${pct}%">${text}</span>`;

    let html = '';

    const renderTier = (config) => {
      let tierHtml = createTier(config.className, config.opacity);
      config.items.forEach(item => {
        tierHtml += label(item.pct, item.text);
      });
      return tierHtml + '</div>';
    };

    // 1. Years Tier
    const years = [];
    for (let y = start.getFullYear(); y <= end.getFullYear(); y++) {
      const d = new Date(y, 0, 1);
      const pct = ((d.getTime() - start.getTime()) / totalMs) * 100;
      if (pct >= -5 && pct <= 105) years.push({ pct, text: y });
    }
    html += renderTier({ className: 'tl-axis-years', opacity: clamp(daysInRange / 180, 0.3, 1), items: years });

    // 2. Months Tier (Adaptive Formatting)
    const months = [];
    let monthFormat = 'short';
    if (daysInRange < 60) monthFormat = 'long';
    if (daysInRange > 400) monthFormat = 'narrow';

    let currM = new Date(start.getFullYear(), start.getMonth(), 1);
    while (currM <= end) {
      const pct = ((currM.getTime() - start.getTime()) / totalMs) * 100;
      if (pct >= -5 && pct <= 105) {
        months.push({ 
          pct, 
          text: currM.toLocaleDateString('en-US', { month: monthFormat }) 
        });
      }
      currM.setMonth(currM.getMonth() + 1);
    }
    html += renderTier({ className: 'tl-axis-months', opacity: clamp(daysInRange / 14, 0.2, 0.9), items: months });

    // 3. Days Tier (Adaptive Step)
    if (daysInRange < 120) {
      const days = [];
      let step = 1;
      if (daysInRange > 30) step = 5;
      if (daysInRange > 60) step = 10;

      let currD = new Date(start.getFullYear(), start.getMonth(), start.getDate());
      currD.setHours(0,0,0,0);
      
      while (currD <= end) {
        if (currD.getDate() === 1 || currD.getDate() % step === 0) {
          const pct = ((currD.getTime() - start.getTime()) / totalMs) * 100;
          if (pct >= -2 && pct <= 102) {
            days.push({ pct, text: currD.getDate() === 1 ? currD.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : currD.getDate() });
          }
        }
        currD.setDate(currD.getDate() + 1);
      }
      html += renderTier({ className: 'tl-axis-days', opacity: clamp(40 / daysInRange, 0, 1), items: days });
    }

    // 4. Hours Tier (Frequency Ladder)
    if (daysInRange < 10) {
      const hours = [];
      let hStep = 1;
      if (daysInRange > 0.5) hStep = 3;
      if (daysInRange > 2) hStep = 6;
      if (daysInRange > 5) hStep = 12;

      let currH = new Date(start);
      currH.setMinutes(0, 0, 0);
      let iterations = 0;
      while (currH <= end && iterations < 300) {
        iterations++;
        if (currH.getHours() % hStep === 0) {
          const pct = ((currH.getTime() - start.getTime()) / totalMs) * 100;
          if (pct >= -2 && pct <= 102) {
            const h = currH.getHours();
            const ampm = h >= 12 ? 'PM' : 'AM';
            const displayH = h % 12 || 12;
            hours.push({ pct, text: daysInRange < 1 ? `${displayH}${ampm}` : `${displayH}:00` });
          }
        }
        currH.setHours(currH.getHours() + 1);
      }
      html += renderTier({ className: 'tl-axis-hours', opacity: clamp(2 / daysInRange, 0, 1), items: hours });
    }

    return html;
  };

  return `
    <div class="tl-container">
      <div class="tl-progress-row">
        <div class="tl-progress-bar">
          <div class="tl-progress-fill" style="width:${Math.max(progress, 0)}%"></div>
        </div>
        <span class="tl-progress-label">${progress >= 0 ? `${progress}%` : '—'}</span>
      </div>
      <div class="tl-scroll">
        <div class="tl-track" data-draggable-track data-tl-track>
          <div class="tl-axis-container">
            ${renderAxis()}
          </div>
          <div class="tl-line">
            <div class="tl-line-fill" style="width:${Math.max(progress, 0)}%"></div>
          </div>

          ${sorted.map((m, i) => {
            const dateMs = new Date(m.date + 'T00:00:00').getTime();
            const pct = ((dateMs - start.getTime()) / totalMs) * 100;
            const subtasks = m.subtasks || [];
            const fileCount = (m.fileIds || []).length;
            const isOpen = activeModalId === m.id;
            const estLabel = m.estimatedDays ? `${m.estimatedDays}d` : '';

            // Only render if within or near the visible viewport for performance
            if (pct < -10 || pct > 110) return '';

            return `
              <div class="tl-node ${m.completed ? 'forest-completed' : ''} ${isOpen ? 'forest-active' : ''}"
                   style="left:${pct}%"
                   data-milestone-id="${m.id}"
                   data-draggable-node>
                <button class="tl-dot" data-action="open-milestone-modal" data-milestone-id="${m.id}" title="Click to expand · Drag to reorder">
                  ${m.completed
                    ? '<span class="jr-sf-symbol" aria-hidden="true">􀆅</span>'
                    : `<span class="tl-dot-index">${i + 1}</span>`}
                </button>
                <div class="tl-node-info">
                  <span class="tl-node-label">${escapeHtml(m.label)}</span>
                  <span class="tl-node-date">${formatMilestoneDate(m.date)}</span>
                  <div class="tl-node-chips">
                    ${fileCount ? `<span class="tl-node-chip">${fileCount} file${fileCount > 1 ? 's' : ''}</span>` : ''}
                    ${estLabel ? `<span class="tl-node-chip">${estLabel}</span>` : ''}
                    ${subtasks.length ? `<span class="tl-node-chip">${subtasks.filter((s) => s.done).length}/${subtasks.length}</span>` : ''}
                  </div>
                </div>

                ${isOpen ? renderMilestoneModal(m, project) : ''}
              </div>
            `;
          }).join('')}

          ${tlGhost ? `
            <div class="tl-ghost" style="left:${tlGhost.pct}%" data-ghost-node>
              <div class="tl-ghost-label">${formatTimelineDate(tlGhost.snappedDate, tlZoom)}</div>
            </div>
          ` : ''}

          ${tlPending ? `
            <div class="tl-pending-indicator">
              <span>Click to place milestone at ${formatTimelineDate(tlPending, tlZoom)}</span>
            </div>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

function renderViewer(project) {
  if (!project) return '';

  const progress = projectProgress(project);
  const level = projectActivityLevel(project);
  const activeFilters = state.viewerTagFilter;

  /* filtered file set */
  const filteredFiles = activeFilters.size === 0
    ? project.files
    : project.files.filter((f) => (f.tags || []).some((t) => activeFilters.has(t)));

  const filteredByType = new Map();
  filteredFiles.forEach((f) => {
    if (!filteredByType.has(f.typeGroup)) filteredByType.set(f.typeGroup, []);
    filteredByType.get(f.typeGroup).push(f);
  });

  /* hero images (visual media only) */
  const heroImages = project.files.filter((f) => f.previewable && !isAudioFile(f)).slice(0, 5);

  /* total estimates */
  const totalDays = (project.milestones || []).reduce((sum, m) => sum + (m.estimatedDays || 0), 0);
  const scoringFieldsSet = ['deadline', 'importance', 'size', 'relevance']
    .filter((field) => project[field] !== null && project[field] !== undefined && project[field] !== '').length;

  return `
    <div class="viewer-backdrop" data-action="close-viewer"></div>
    <div class="viewer-content" style="--accent:${project.accent}; --accent-rgb:${project.accentRgb};">

      <div class="viewer-hero ${heroImages.length ? '' : 'viewer-hero--empty'}">
        ${heroImages.length
          ? heroImages.map((f) => renderPreviewMedia(f, 'viewer-hero-img')).join('')
          : '<div class="viewer-hero-pattern"></div>'}
      </div>

      <div class="viewer-body">
        <div class="viewer-header">
          <div class="viewer-emblem">${escapeHtml((project.name || 'P').trim().slice(0, 2).toUpperCase())}</div>
          <div class="viewer-title-area">
            <h2 class="viewer-title">${escapeHtml(project.name)}</h2>
            <div class="viewer-meta">
              <span class="viewer-meta-pill">${project.files.length} file${project.files.length === 1 ? '' : 's'}</span>
              <span class="viewer-meta-pill">${relativeDate(project.createdAt)}</span>
              <span class="viewer-meta-pill activity-${level}">${activityLabel(level)}</span>
              ${progress >= 0 ? `<span class="viewer-meta-pill viewer-meta-progress">${progress}%</span>` : ''}
              ${totalDays ? `<span class="viewer-meta-pill">${totalDays}d est.</span>` : ''}
            </div>
          </div>
          <button class="viewer-close" data-action="close-viewer" title="Close viewer">✕</button>
        </div>

        <div class="viewer-tags">
          ${project.tags.map((tag) => `
            <button class="viewer-tag-btn ${activeFilters.has(tag) ? 'forest-active' : ''}"
                    data-action="toggle-tag-filter" data-tag="${escapeAttr(tag)}">
              #${escapeHtml(tag)}
            </button>
          `).join('')}
          ${activeFilters.size > 0 ? `<button class="viewer-tag-clear" data-action="clear-tag-filter">Clear</button>` : ''}
        </div>

        <section class="viewer-section viewer-priority-section">
          <div class="viewer-section-header viewer-priority-header">
            <div>
              <h3>Priority signals</h3>
              <p>Optional context used when briizOS helps choose what comes next.</p>
            </div>
            <span class="viewer-priority-completeness">${scoringFieldsSet} / 4 set</span>
          </div>
          <div class="viewer-priority-grid">
            <label class="viewer-priority-field">
              <span>Deadline</span>
              <input
                type="date"
                value="${escapeAttr(project.deadline || '')}"
                data-role="project-score-deadline"
              />
            </label>
            <label class="viewer-priority-field viewer-priority-field--compact">
              <span>Importance</span>
              <input
                type="number"
                min="1"
                max="10"
                step="1"
                inputmode="numeric"
                placeholder="1–10"
                value="${project.importance ?? ''}"
                data-role="project-score-importance"
              />
            </label>
            <label class="viewer-priority-field viewer-priority-field--compact">
              <span>Size</span>
              <div class="viewer-priority-input-unit">
                <input
                  type="number"
                  min="0"
                  step="0.25"
                  inputmode="decimal"
                  placeholder="Hours"
                  value="${project.size ?? ''}"
                  data-role="project-score-size"
                />
                <span>h</span>
              </div>
            </label>
            <label class="viewer-priority-field viewer-priority-field--relevance">
              <span>Relevance to your goals</span>
              <input
                type="text"
                maxlength="5000"
                placeholder="Why this matters now"
                value="${escapeAttr(project.relevance || '')}"
                data-role="project-score-relevance"
              />
            </label>
          </div>
        </section>

        <section class="viewer-section viewer-timeline-section">
          <div class="viewer-section-header">
            <div class="viewer-section-title-row">
              <h3>Timeline</h3>
              <div class="viewer-timeline-actions">
                <button class="viewer-timeline-action-btn tl-add-toggle ${state.tlAddMode ? 'forest-active' : ''}" data-action="toggle-add-mode" title="Toggle add-milestone mode">${state.tlAddMode ? '✓ Adding' : '+ Add'}</button>
                <button class="viewer-timeline-action-btn" data-action="zoom-fit" title="Zoom to view all milestones">Zoom Fit</button>
                <button class="viewer-timeline-action-btn" data-action="next-node" title="Jump to next milestone">Next Node</button>
              </div>
            </div>
            ${progress >= 0 ? `<span class="viewer-progress-chip">${progress}% complete</span>` : ''}
          </div>
          ${renderMilestoneTimeline(project)}
        </section>

        ${(() => {
          const previewable = filteredFiles.filter((f) => f.previewable);
          if (!previewable.length) return '';
          return `
            <section class="viewer-section">
              <div class="viewer-section-header">
                <h3>Preview</h3>
                <span class="viewer-file-total">${previewable.length}</span>
              </div>
              <div class="viewer-carousel">
                ${previewable.map((f) => `
                  <div class="viewer-carousel-item" data-action="open-file" data-project-id="${project.id}" data-file-id="${f.id}" title="${escapeAttr(f.name)}">
                    ${renderPreviewMedia(f, 'viewer-carousel-img')}
                    <div class="viewer-carousel-label">${escapeHtml(f.name)}</div>
                  </div>
                `).join('')}
              </div>
            </section>
          `;
        })()}

        <section class="viewer-section">
          <div class="viewer-section-header">
            <h3>Files${activeFilters.size > 0 ? ' <span class="viewer-filter-note">filtered</span>' : ''}</h3>
            <span class="viewer-file-total">${filteredFiles.length === project.files.length ? `${project.files.length}` : `${filteredFiles.length} / ${project.files.length}`}</span>
          </div>
          <div class="viewer-file-groups">
            ${Array.from(filteredByType.entries())
              .sort((a, b) => TYPE_ORDER.indexOf(a[0]) - TYPE_ORDER.indexOf(b[0]))
              .map(([group, files]) => `
                <details class="viewer-file-group" open>
                  <summary>${readableGroup(group)} <span class="viewer-group-count">${files.length}</span></summary>
                  <div class="viewer-file-list">
                    ${files.map((f) => {
                      const linkedMs = (project.milestones || []).filter((m) => (m.fileIds || []).includes(f.id));
                      return `
                        <div class="file-row" data-action="open-file" data-project-id="${project.id}" data-file-id="${f.id}" title="${escapeAttr(f.path)}">
                          <div class="file-badge">${escapeHtml(fileBadgeLabel(f))}</div>
                          <div class="file-copy">
                            <div class="forest-file-name">${escapeHtml(f.name)}</div>
                            <div class="file-sub">${formatBytes(f.size)} · ${relativeDate(f.modifiedAt)}${linkedMs.length ? ` · ${linkedMs.map((m) => m.label).join(', ')}` : ''}</div>
                          </div>
                          <button class="tiny-btn" data-action="show-file" data-project-id="${project.id}" data-file-id="${f.id}" title="Reveal in folder">↗</button>
                        </div>
                      `;
                    }).join('')}
                  </div>
                </details>
              `).join('')}
          </div>
        </section>

        ${project.consolidated ? '<div class="consolidated-badge">✓ Files consolidated</div>' : ''}
      </div>
    </div>
  `;
}

function refreshViewer() {
  const project = getProject(state.viewerProjectId);
  if (!project) return;
  projectViewer.innerHTML = renderViewer(project);
}

function openViewer(projectId) {
  state.viewerProjectId = projectId;
  state.viewerActiveModal = null;
  state.viewerTagFilter = new Set();
  state.viewerDrag = null;
  const project = getProject(projectId);
  if (!project) return;
  projectViewer.innerHTML = renderViewer(project);
  projectViewer.classList.remove('forest-hidden');
}

function closeViewer() {
  state.viewerProjectId = null;
  state.viewerActiveModal = null;
  state.viewerTagFilter = new Set();
  state.viewerDrag = null;
  projectViewer.classList.add('forest-hidden');
  projectViewer.innerHTML = '';
}

/* ── Hunter ─────────────────────────────────────────────────────────── */

let hunterDebounce = null;

function hunterSuggestKeywords(project) {
  return [...(project.tags || []), ...project.name.toLowerCase().split(/\s+/)]
    .filter((k) => k.length > 2);
}

function openHunter(projectId) {
  const project = getProject(projectId);
  if (!project) return;
  state.hunterProjectId = projectId;
  state.hunterRelocate = null;
  state.hunterQueryStr = '';
  state.hunterTypes = new Set();
  state.hunterSelected = new Set();
  state.hunterResults = [];
  hunterPanel.classList.remove('forest-hidden');
  renderHunterPanel();
  runHunterSearch(); // initial suggestions
}

function openHunterRelocate(projectId, file) {
  const project = getProject(projectId);
  if (!project) return;
  state.hunterProjectId = projectId;
  state.hunterRelocate = { fileId: file.id, fileName: file.name };
  state.hunterQueryStr = file.name;
  state.hunterTypes = new Set();
  state.hunterSelected = new Set();
  state.hunterResults = [];
  state.hunterLoading = true;
  hunterPanel.classList.remove('forest-hidden');
  renderHunterPanel();
  window.api
    .forestFilehawkLocate(file.name, project.files.map((f) => f.path), state.hunterDirs)
    .then((res) => { state.hunterResults = res || []; })
    .catch((err) => { console.error('Relocate search failed:', err); state.hunterResults = []; })
    .finally(() => { state.hunterLoading = false; refreshHunterResults(); });
}

async function runHunterSearch() {
  const project = getProject(state.hunterProjectId);
  if (destroyed || !project || state.hunterRelocate) return;

  state.hunterLoading = true;
  state.hunterSelected = new Set();
  refreshHunterResults();

  const excludePaths = project.files.map((f) => f.path);
  const types = state.hunterTypes.size ? Array.from(state.hunterTypes) : null;
  const q = state.hunterQueryStr.trim();

  try {
    const opts = q
      ? { query: q, types, excludePaths, customDirs: state.hunterDirs, limit: 80 }
      : { keywords: hunterSuggestKeywords(project), types, excludePaths, customDirs: state.hunterDirs, limit: 40 };
    const results = await window.api.forestHunterQuery(opts);
    if (destroyed) return;
    state.hunterResults = results || [];
  } catch (err) {
    console.error('Hunter query failed:', err);
    state.hunterResults = [];
  }

  state.hunterLoading = false;
  refreshHunterResults();
}

const HUNTER_TYPES = ['image', 'video', 'audio', 'pdf', 'document', 'spreadsheet', 'slides', 'design', 'code', 'archive', 'data'];

function hunterResultsMarkup() {
  const relocate = state.hunterRelocate;
  const selected = state.hunterSelected;
  const results = state.hunterResults;
  const showingSuggestions = !state.hunterQueryStr.trim() && !relocate;

  if (state.hunterLoading) {
    return '<div class="hunter-loading">Searching your filesystem…</div>';
  }
  if (!results.length) {
    const msg = state.hunterQueryStr.trim() || relocate
      ? 'No matching files found.'
      : 'No suggestions yet — type above to search.';
    return `<div class="hunter-empty">${msg}</div>`;
  }

  const head = showingSuggestions
    ? '<div class="hunter-section-label">Suggested related files</div>'
    : `<div class="hunter-count">${results.length} match${results.length === 1 ? '' : 'es'}</div>`;

  const rows = results.map((file) => `
    <div class="hunter-result ${selected.has(file.path) ? 'forest-selected' : ''}">
      ${relocate ? '' : `<input type="checkbox" class="hunter-check" data-action="hunter-select" data-path="${escapeAttr(file.path)}" ${selected.has(file.path) ? 'checked' : ''} />`}
      <div class="file-badge">${escapeHtml(fileBadgeLabel(file))}</div>
      <div class="file-copy">
        <div class="forest-file-name">${escapeHtml(file.name)}</div>
        <div class="file-sub">${escapeHtml(file.path)}</div>
      </div>
      <button class="forest-action-btn hunter-add-btn" data-action="${relocate ? 'hunter-relink' : 'hunter-add-file'}" data-path="${escapeAttr(file.path)}">${relocate ? 'Use this' : '+ Add'}</button>
    </div>
  `).join('');

  const addbar = (!relocate && selected.size)
    ? `<div class="hunter-addbar"><button class="forest-action-btn forest-primary" data-action="hunter-add-selected">+ Add ${selected.size} selected</button></div>`
    : '';

  return `${head}<div class="hunter-results">${rows}</div>${addbar}`;
}

function refreshHunterResults() {
  if (destroyed) return;
  const el = host.querySelector('#hunterResults');
  if (el) el.innerHTML = hunterResultsMarkup();
  else renderHunterPanel();
}

function renderHunterPanel() {
  const project = getProject(state.hunterProjectId);
  if (!project) {
    hunterPanel.classList.add('forest-hidden');
    return;
  }

  const relocate = state.hunterRelocate;

  const dirList = state.hunterDirs.length
    ? state.hunterDirs
        .map((d, i) => `
          <div class="hunter-dir-row">
            <span class="hunter-dir-path" title="${escapeAttr(d)}">${escapeHtml(d)}</span>
            <button class="tag-x hunter-dir-remove" data-action="hunter-remove-dir" data-index="${i}" title="Remove">×</button>
          </div>
        `).join('')
    : '<div class="hunter-dir-default">Default: Desktop, Documents, Downloads, Pictures, Movies, Music</div>';

  const typeChips = HUNTER_TYPES
    .map((t) => `<button class="hunter-type-chip ${state.hunterTypes.has(t) ? 'forest-active' : ''}" data-action="hunter-type" data-type="${t}">${TYPE_LABELS[t] || t}</button>`)
    .join('');

  hunterPanel.innerHTML = `
    <div class="cv-slideout-head">
      <div class="cv-slideout-title">
        <span class="cv-slideout-kicker">${relocate ? 'Relocate' : '⌕ Hunter'}</span>
        <h3>${relocate ? `Find “${escapeHtml(relocate.fileName)}”` : escapeHtml(project.name)}</h3>
      </div>
      <button class="icon-btn" data-action="close-hunter" title="Close">✕</button>
    </div>

    ${relocate
      ? `<div class="cv-slideout-sub">Pick the file's new location to re-link it.</div>`
      : `
        <div class="hunter-search-row">
          <input class="hunter-search-input" data-role="hunter-query" placeholder="Search files by name…" value="${escapeAttr(state.hunterQueryStr)}" autocomplete="off" spellcheck="false" />
        </div>
        <div class="hunter-type-chips">${typeChips}</div>
      `}

    <details class="hunter-dirs-section">
      <summary class="hunter-dirs-toggle">Search folders</summary>
      <div class="hunter-dirs-list">${dirList}</div>
      <button class="forest-action-btn hunter-add-dir-btn" data-action="hunter-add-dir">+ Add folder</button>
    </details>

    <div id="hunterResults" class="hunter-results-region">${hunterResultsMarkup()}</div>
  `;
}

function positionHunterPanel() {
  /* Hunter is now a fixed right-side slideout; positioning handled by CSS. */
}

function closeHunter() {
  state.hunterProjectId = null;
  state.hunterResults = [];
  state.hunterRelocate = null;
  state.hunterSelected = new Set();
  state.hunterQueryStr = '';
  hunterPanel.classList.add('forest-hidden');
  hunterPanel.innerHTML = '';
}

/* ── File Consolidation ─────────────────────────────────────────────── */

async function consolidateFiles(projectId) {
  const project = getProject(projectId);
  if (!project || !project.files.length) return;

  setSaveStatus('Consolidating…');
  try {
    const filePaths = project.files.map((f) => f.path);
    const result = await window.api.forestConsolidateProject(project.name, filePaths);
    if (destroyed) return;
    project.consolidated = true;
    render();
    scheduleSave(true);
    setSaveStatus(`Consolidated: ${result.copied} copied, ${result.skipped} skipped`);
  } catch (err) {
    console.error('Consolidation failed:', err);
    setSaveStatus('Consolidation failed');
  }
}

/* ── FileHawk: periodic scan ───────────────────────────────────────── */

async function filehawkScan() {
  if (destroyed || !state.projects.length) return;

  if (state.filehawkScanning) return;
  const allPaths = [...new Set(state.projects.flatMap((p) => p.files.filter(f => f.filehawk).map((f) => f.path)))];
  if (!allPaths.length) {
    state.filehawkStatus = {};
    if (state.filehawkOpen) renderFilehawkPanel();
    return;
  }

  state.filehawkScanning = true;
  if (state.filehawkOpen) renderFilehawkPanel();

  try {
    dispatchForestLog('info', 'FileHawk checking manually designated files', { count: allPaths.length });
    const results = await window.api.forestFilehawkCheck(allPaths);
    if (destroyed) return;
    const statMap = new Map(results.map((r) => [r.path, r]));
    const status = {};
    let changed = false;

    state.projects.forEach((project) => {
      project.files.filter(file => file.filehawk).forEach((file) => {
        const info = statMap.get(file.path);
        if (!info || !info.exists) {
          status[file.path] = 'missing';
          return;
        }
        if (info.modifiedAt !== file.modifiedAt) {
          file.modifiedAt = info.modifiedAt;
          file.size = info.size;
          status[file.path] = 'modified';
          changed = true;
        } else {
          status[file.path] = 'ok';
        }
      });
    });

    state.filehawkStatus = status;
    state.filehawkScanAt = Date.now();
    render();
    if (changed) scheduleSave();
  } catch (err) {
    dispatchForestLog('error', 'FileHawk could not complete its scan', { error: err.message });
  } finally {
    state.filehawkScanning = false;
    if (!destroyed && state.filehawkOpen) renderFilehawkPanel();
  }
}

function filehawkProblemCount() {
  return Object.values(state.filehawkStatus || {}).filter((s) => s === 'missing').length;
}

function openFilehawk() {
  state.filehawkOpen = true;
  filehawkPanel.classList.remove('forest-hidden');
  renderFilehawkPanel();
  filehawkScan();
}

function closeFilehawk() {
  state.filehawkOpen = false;
  filehawkPanel.classList.add('forest-hidden');
  filehawkPanel.innerHTML = '';
}

function renderFilehawkPanel() {
  if (!state.filehawkOpen) {
    filehawkPanel.classList.add('forest-hidden');
    return;
  }
  const status = state.filehawkStatus || {};
  const missing = filehawkProblemCount();
  const scanned = state.filehawkScanAt
    ? relativeDate(new Date(state.filehawkScanAt).toISOString())
    : 'never';

  const groups = state.projects
    .map((p) => {
      const rows = p.files.filter(f => f.filehawk).map((f) => ({ f, st: status[f.path] || 'pending' }));
      return { p, rows, missing: rows.filter((r) => r.st === 'missing').length };
    })
    .filter((g) => g.rows.length)
    .sort((a, b) => b.missing - a.missing);

  filehawkPanel.innerHTML = `
    <div class="cv-slideout-head">
      <div class="cv-slideout-title">
        <span class="cv-slideout-kicker">FileHawk</span>
        <h3>${missing ? `${missing} missing file${missing === 1 ? '' : 's'}` : state.filehawkScanAt ? 'Designated files' : 'Choose files to watch'}</h3>
      </div>
      <div class="cv-slideout-head-actions">
        <button class="forest-action-btn" data-action="filehawk-rescan" ${state.filehawkScanning ? 'disabled' : ''}>${state.filehawkScanning ? 'Scanning…' : '↻ Rescan'}</button>
        <button class="icon-btn" data-action="filehawk-close" title="Close">✕</button>
      </div>
    </div>
    <div class="cv-slideout-sub">Last scan ${scanned} · ${state.projects.length} project${state.projects.length === 1 ? '' : 's'}</div>
    <div class="cv-slideout-body">
      ${groups.length ? groups.map((g) => `
        <div class="fh-group ${g.missing ? 'has-missing' : ''}">
          <div class="fh-group-head">
            <span class="fh-group-name">${escapeHtml(g.p.name)}</span>
            <span class="fh-group-meta">${g.missing ? `${g.missing} missing` : `${g.rows.length} file${g.rows.length === 1 ? '' : 's'}`}</span>
          </div>
          ${g.rows.map(({ f, st }) => `
            <div class="fh-row fh-${st}">
              <span class="fh-status" title="${st}"></span>
              <div class="file-copy">
                <div class="forest-file-name">${escapeHtml(f.name)}</div>
                <div class="file-sub">${escapeHtml(f.path)}</div>
              </div>
              ${st === 'missing'
                ? `<div class="fh-row-actions">
                     <button class="forest-action-btn" data-action="filehawk-relocate" data-project-id="${g.p.id}" data-file-id="${f.id}">Relocate</button>
                     <button class="tiny-btn" data-action="filehawk-remove" data-project-id="${g.p.id}" data-file-id="${f.id}" title="Remove broken reference">✕</button>
                   </div>`
                : `<span class="fh-row-tag">${st}</span>`}
              <button class="tiny-btn" data-action="filehawk-unwatch" data-project-id="${g.p.id}" data-file-id="${f.id}">Stop watching</button>
            </div>
          `).join('')}
        </div>
      `).join('') : '<div class="cv-slideout-empty">No files designated yet. Open a project’s FileHawk suggestions tab to choose files to watch.</div>'}
    </div>
  `;
}

function startFileHawk() {
  if (filehawkTimer) clearInterval(filehawkTimer);
  filehawkScan();
  filehawkTimer = setInterval(filehawkScan, 4 * 60 * 60 * 1000);
}

function updateStats() {
  const totalFiles = state.projects.reduce((sum, project) => sum + project.files.length, 0);
  projectCountEl.textContent = `${state.projects.length} project${state.projects.length === 1 ? '' : 's'}`;
  fileCountEl.textContent = `${totalFiles} file${totalFiles === 1 ? '' : 's'}`;
  zoomReadoutEl.textContent = `${Math.round(state.viewport.scale * 100)}%`;

  if (collapseAllBtn) {
    const hasExpandedProjects = state.projects.some((project) => project.expanded);
    const collapseLabel = hasExpandedProjects
      ? 'Collapse all expanded projects'
      : 'All projects are already mini';

    collapseAllBtn.disabled = !hasExpandedProjects;
    collapseAllBtn.dataset.state = hasExpandedProjects ? 'expanded' : 'mini';
    collapseAllBtn.setAttribute('aria-label', collapseLabel);
    collapseAllBtn.title = collapseLabel;
  }

  if (filehawkBtn) {
    const probs = filehawkProblemCount();
    filehawkBtn.classList.toggle('has-alert', probs > 0);
    filehawkBtn.innerHTML = probs ? `FileHawk <span class="fh-badge">${probs}</span>` : 'FileHawk';
  }
}

// Tags whose bloom has already sprouted. renderTagStrip rebuilds the strip's
// innerHTML on every render, which would restart CSS animations — so the
// sprout animation only plays the first render after a tag becomes active.
const bloomedTags = new Set();

const BLOOM_SPRITE = `
  <svg class="tag-bloom-sprite" viewBox="0 0 28 72" preserveAspectRatio="none" aria-hidden="true">
    <path class="bloom-stem" d="M14 70 C 10.5 58, 17.5 46, 13.8 12" fill="none"/>
    <path class="bloom-leaf left" d="M13.2 44 C 6.4 42.6, 3.2 37.4, 2.6 32 C 8.8 33.4, 12.4 37.8, 13.2 44 Z"/>
    <path class="bloom-leaf right" d="M14.6 34 C 21.4 32.4, 24.6 27.2, 25.2 21.8 C 19 23.2, 15.4 27.6, 14.6 34 Z"/>
    <g class="bloom-petals">
      <ellipse cx="8" cy="13" rx="4.4" ry="2.9" transform="rotate(-35 8 13)"/>
      <ellipse cx="20" cy="13" rx="4.4" ry="2.9" transform="rotate(35 20 13)"/>
      <ellipse class="crown" cx="14" cy="10" rx="4.8" ry="3.2"/>
    </g>
  </svg>`;

function renderTagStrip() {
  const counts = new Map();

  state.projects.forEach((project) => {
    project.tags.forEach((tag) => {
      counts.set(tag, (counts.get(tag) || 0) + 1);
    });
  });

  const tags = Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, 16);

  if (!tags.length) {
    bloomedTags.clear();
    tagStrip.innerHTML = `<div class="tag-strip-empty">Drop files to generate smart tags and quick filters.</div>`;
    return;
  }

  const activeTags = new Set(parseQuery(state.query).tags);
  bloomedTags.forEach((tag) => {
    if (!activeTags.has(tag)) bloomedTags.delete(tag);
  });

  tagStrip.innerHTML = tags.map(([tag, count]) => {
    const key = normalizeText(tag);
    const active = activeTags.has(key);
    const sprouting = active && !bloomedTags.has(key);
    if (sprouting) bloomedTags.add(key);
    const slotClass = `global-tag-slot${active ? ' is-bloomed' : ''}${sprouting ? ' is-sprouting' : ''}`;
    // Each tag's flower gets a stable personality from its name hash — stem
    // height, sprout speed, and leaf flutter vary between flowers but never
    // between re-renders (a random roll would reshuffle on every render).
    let bloomStyle = '';
    if (active) {
      const seed = hashString(key);
      const lift = 48 + (seed % 13);
      const sproutMs = 420 + ((seed >>> 4) % 200);
      const delayMs = ((seed >>> 8) % 5) * 30;
      const flutterMs = 2600 + ((seed >>> 6) % 1400);
      bloomStyle = ` style="--bloom-lift:${lift}px;--bloom-dur:${sproutMs}ms;--bloom-delay:${delayMs}ms;--bloom-flutter:${flutterMs}ms"`;
    }
    return `
    <span class="${slotClass}"${bloomStyle}>
      ${active ? BLOOM_SPRITE : ''}
      <button class="global-tag" data-tag="${escapeAttr(tag)}" aria-pressed="${active}"
        title="${active ? 'Clear this tag filter' : 'Filter by this tag'}">#${escapeHtml(tag)} <span>${count}</span></button>
    </span>`;
  }).join('');
}

function renderEmptyState(visibleProjects) {
  if (!state.projects.length) {
    emptyState.hidden = false;
    emptyState.innerHTML = `
      <div class="empty-card">
        <div class="empty-kicker">Spatial file organization</div>
        <h2>Build a beautiful workspace from folders, references, and media.</h2>
        <p>Drop files or whole folders on the canvas. Projungle will cluster them into projects and keep your original files exactly where they are.</p>
      </div>
    `;
    return;
  }

  if (!visibleProjects.length) {
    emptyState.hidden = false;
    emptyState.innerHTML = `
      <div class="empty-card">
        <div class="empty-kicker">No matches</div>
        <h2>Nothing matches your current search.</h2>
        <p>Try a broader term, remove a #tag, or press Escape to clear the filter.</p>
      </div>
    `;
    return;
  }

  emptyState.hidden = true;
  emptyState.innerHTML = '';
}

function render() {
  if (destroyed) return;
  if (state.selectedProjectId && !state.projects.some((project) => project.id === state.selectedProjectId)) {
    state.selectedProjectId = null;
  }

  const visibleProjects = getVisibleProjects();
  world.innerHTML = visibleProjects.map(renderProject).join('');
  updateStats();
  renderTagStrip();
  renderEmptyState(visibleProjects);
  applyTransform();
}

function updateSelectionHighlight() {
  world.querySelectorAll('.project-card.selected').forEach((card) => card.classList.remove('forest-selected'));
  if (!state.selectedProjectId) return;

  const card = world.querySelector(`.project-card[data-id="${state.selectedProjectId}"]`);
  if (card) card.classList.add('forest-selected');
}

function applyTransform() {
  world.style.transform = `translate(${state.viewport.x}px, ${state.viewport.y}px) scale(${state.viewport.scale})`;

  const minor = Math.max(24, 48 * state.viewport.scale);
  const major = minor * 5;

  grid.style.setProperty('--minor', `${minor}px`);
  grid.style.setProperty('--major', `${major}px`);
  grid.style.setProperty('--off-x', `${positiveMod(state.viewport.x, minor)}px`);
  grid.style.setProperty('--off-y', `${positiveMod(state.viewport.y, minor)}px`);
  grid.style.setProperty('--major-off-x', `${positiveMod(state.viewport.x, major)}px`);
  grid.style.setProperty('--major-off-y', `${positiveMod(state.viewport.y, major)}px`);

  zoomReadoutEl.textContent = `${Math.round(state.viewport.scale * 100)}%`;
  positionHunterPanel();
}

function screenToWorld(clientX, clientY) {
  const rect = stage.getBoundingClientRect();
  return {
    x: (clientX - rect.left - state.viewport.x) / state.viewport.scale,
    y: (clientY - rect.top - state.viewport.y) / state.viewport.scale,
  };
}

function getStageCenter() {
  const rect = stage.getBoundingClientRect();
  return {
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2,
  };
}

function zoomAt(clientX, clientY, multiplier) {
  const rect = stage.getBoundingClientRect();
  const before = screenToWorld(clientX, clientY);
  const nextScale = clamp(state.viewport.scale * multiplier, 0.25, 2.4);

  state.viewport.x = clientX - rect.left - before.x * nextScale;
  state.viewport.y = clientY - rect.top - before.y * nextScale;
  state.viewport.scale = nextScale;

  applyTransform();
  scheduleSave();
}

function resetView(shouldSave = true) {
  state.viewport = {
    x: Math.round(stage.clientWidth * 0.25),
    y: Math.round(stage.clientHeight * 0.18),
    scale: 1,
  };

  applyTransform();
  if (shouldSave) scheduleSave();
}

function estimateCardHeight(project) {
  return project.expanded ? 520 : 260;
}

function fitProjects(projects = getVisibleProjects()) {
  if (!projects.length) return;

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  projects.forEach((project) => {
    minX = Math.min(minX, project.x);
    minY = Math.min(minY, project.y);
    maxX = Math.max(maxX, project.x + PROJECT_CARD_WIDTH);
    maxY = Math.max(maxY, project.y + estimateCardHeight(project));
  });

  const pad = 220;
  const width = Math.max(1, maxX - minX);
  const height = Math.max(1, maxY - minY);

  state.viewport.scale = clamp(
    Math.min(
      (stage.clientWidth - pad) / width,
      (stage.clientHeight - pad) / height,
      1.3
    ),
    0.25,
    1.3
  );

  state.viewport.x = stage.clientWidth / 2 - (minX + width / 2) * state.viewport.scale;
  state.viewport.y = stage.clientHeight / 2 - (minY + height / 2) * state.viewport.scale;

  applyTransform();
  scheduleSave();
}

function normalizedProjectName(name) {
  return normalizeText(name).replace(/\s+/g, ' ');
}

function mergeGroupIntoProject(group, target) {
  const knownPaths = new Set(target.files.map((file) => file.path));
  let added = 0;

  (group.files || []).forEach((rawFile) => {
    const file = normalizeFile(rawFile);
    if (!file.path || knownPaths.has(file.path)) return;

    target.files.push(file);
    knownPaths.add(file.path);
    added += 1;
  });

  target.tags = dedupe([
    ...target.tags,
    ...((group.tags || []).map(cleanTag)),
  ]).slice(0, 24);

  target.files.sort(sortFiles);
  return added;
}

function createProjectFromImport(group, x, y) {
  const accent = accentForSeed(group.name || uid());

  return normalizeProject({
    id: uid(),
    name: group.name || 'Untitled Project',
    x,
    y,
    expanded: true,
    accent: accent.hex,
    accentRgb: accent.rgb,
    tags: dedupe((group.tags || []).map(cleanTag)).slice(0, 18),
    files: group.files || [],
  });
}

function spiralPoint(origin, index) {
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  const radius = index === 0 ? 0 : 240 * Math.sqrt(index);
  const angle = index * goldenAngle;

  return {
    x: origin.x + Math.cos(angle) * radius,
    y: origin.y + Math.sin(angle) * radius,
  };
}

/**
 * Dry-run capacity check: would merging these groups push any existing
 * project past `maxFilesPerProject`? Returns the first offender (or null)
 * WITHOUT mutating state, so oversized drops are rejected before the
 * board holds anything the DB would refuse to save.
 */
function findMergeOverflow(importedGroups, forcedProjectId, maxFilesPerProject) {
  const prospective = new Map();

  for (const group of importedGroups) {
    const target = forcedProjectId
      ? getProject(forcedProjectId)
      : state.projects.find(
          (project) => normalizedProjectName(project.name) === normalizedProjectName(group.name),
        );
    if (!target) continue; // brand-new project — group size already capped at import

    let entry = prospective.get(target.id);
    if (!entry) {
      entry = { name: target.name, paths: new Set(target.files.map((file) => file.path)) };
      prospective.set(target.id, entry);
    }

    for (const file of group.files || []) {
      if (file.path) entry.paths.add(file.path);
    }

    if (entry.paths.size > maxFilesPerProject) {
      return { name: entry.name, total: entry.paths.size };
    }
  }

  return null;
}

function mergeImportedGroups(importedGroups, origin, forcedProjectId = null) {
  let addedFiles = 0;
  let createdProjects = 0;
  let lastTouched = null;

  if (forcedProjectId) {
    const target = getProject(forcedProjectId);
    if (!target) return { addedFiles: 0, createdProjects: 0 };

    importedGroups.forEach((group) => {
      addedFiles += mergeGroupIntoProject(group, target);
    });

    target.expanded = true;
    lastTouched = target.id;
  } else {
    const newGroups = [];

    importedGroups.forEach((group) => {
      const existing = state.projects.find(
        (project) => normalizedProjectName(project.name) === normalizedProjectName(group.name),
      );

      if (existing) {
        addedFiles += mergeGroupIntoProject(group, existing);
        existing.expanded = true;
        lastTouched = existing.id;
      } else {
        newGroups.push(group);
      }
    });

    newGroups.forEach((group, index) => {
      const point = spiralPoint(origin, index);
      const project = createProjectFromImport(group, point.x, point.y);
      state.projects.push(project);
      addedFiles += project.files.length;
      createdProjects += 1;
      lastTouched = project.id;
    });
  }

  if (lastTouched) state.selectedProjectId = lastTouched;

  return { addedFiles, createdProjects };
}

function isFileDrag(event) {
  return Array.from(event.dataTransfer?.types || []).includes('Files');
}

function showDropOverlay() {
  dropOverlay.classList.remove('forest-hidden');
}

function hideDropOverlay() {
  dropOverlay.classList.add('forest-hidden');
}

async function openFile(projectId, fileId) {
  const file = getFile(projectId, fileId);
  if (!file) return;
  await window.api.forestOpenPath(file.path);
}

async function revealFile(projectId, fileId) {
  const file = getFile(projectId, fileId);
  if (!file) return;
  await window.api.forestShowItemInFolder(file.path);
}

async function handleDrop(event) {
  if (!isFileDrag(event)) return;

  event.preventDefault();
  dragDepth = 0;
  hideDropOverlay();

  const paths = dedupe(Array.from(event.dataTransfer.files || []).map((file) => window.api.mediaGetFilePath(file)).filter(Boolean));
  if (!paths.length) return;

  setSaveStatus('Importing…');

  try {
    const imported = await window.api.forestImportPaths(paths);
    if (destroyed) return;

    if (imported?.rejected) {
      setSaveStatus(`Import rejected: ${imported.rejected.message}`);
      dispatchForestLog('warn', 'Import rejected', { reason: imported.rejected.reason, ...imported.stats });
      return;
    }

    const importedGroups = imported?.groups || [];
    const ignored = imported?.stats?.ignored || 0;

    if (!importedGroups.length) {
      setSaveStatus(ignored ? `Nothing imported (${ignored} ignored)` : 'Nothing imported');
      return;
    }

    const dropTarget = document.elementFromPoint(event.clientX, event.clientY)?.closest('.project-card');
    const forcedProjectId = dropTarget?.dataset.id || null;
    const dropPoint = screenToWorld(event.clientX, event.clientY);

    const maxFilesPerProject = imported?.limits?.maxFilesPerProject ?? 10000;
    const overflow = findMergeOverflow(importedGroups, forcedProjectId, maxFilesPerProject);
    if (overflow) {
      setSaveStatus(`Import rejected: "${overflow.name}" would hold ${overflow.total.toLocaleString()} files (max ${maxFilesPerProject.toLocaleString()}) — try a subfolder`);
      dispatchForestLog('warn', 'Import rejected', { project: overflow.name, wouldHold: overflow.total, max: maxFilesPerProject });
      return;
    }

    const result = mergeImportedGroups(importedGroups, dropPoint, forcedProjectId);
    render();

    if (result.addedFiles === 0) {
      setSaveStatus('No new files added');
      return;
    }

    dispatchForestLog('info', 'Files imported into board', { addedFiles: result.addedFiles, ignored, paths: paths.length });
    scheduleSave(true);
  } catch (error) {
    console.error(error);
    setSaveStatus('Import failed');
    dispatchForestLog('error', 'File import failed', error?.message);
  }
}

function selectProjectCard(card) {
  state.selectedProjectId = card?.dataset.id || null;
  updateSelectionHighlight();
}

stage.addEventListener('pointerdown', (event) => {
  if (event.button !== 0) return;
  if (!event.target.closest('input, textarea, button, select, a, [contenteditable]')) {
    stage.focus({ preventScroll: true });
  }

  const card = event.target.closest('.project-card');
  if (card) {
    selectProjectCard(card);
    return;
  }

  state.selectedProjectId = null;
  updateSelectionHighlight();

  interaction = {
    kind: 'pan',
    startClientX: event.clientX,
    startClientY: event.clientY,
    startX: state.viewport.x,
    startY: state.viewport.y,
  };

  forestShell.classList.add('is-panning');
});

world.addEventListener('pointerdown', (event) => {
  if (event.button !== 0) return;

  const card = event.target.closest('.project-card');
  if (!card) return;

  /* ── Cover image drag-to-pan ────────────────────────────── */
  const coverArea = event.target.closest('[data-role="cover-drag-area"]');
  if (coverArea) {
    const project = getProject(card.dataset.id);
    if (!project) return;
    const coverImg = coverArea.querySelector('.project-cover-img, video.project-cover-img');
    if (!coverImg) return;

    const pos = (project.coverPosition || '50% 50%').split(/\s+/).map(parseFloat);

    interaction = {
      kind: 'pan-cover',
      project,
      coverImg,
      startClientX: event.clientX,
      startClientY: event.clientY,
      originX: pos[0] || 50,
      originY: pos[1] || 50,
      containerW: coverArea.offsetWidth,
      containerH: coverArea.offsetHeight,
    };

    event.preventDefault();
    event.stopPropagation();
    return;
  }

  /* ── Card drag ──────────────────────────────────────────── */
  const handle = event.target.closest('[data-drag-handle]');
  const interactive = event.target.closest('button') || event.target.matches('input');

  if (!handle || interactive) return;

  const project = getProject(card.dataset.id);
  if (!project) return;

  state.selectedProjectId = project.id;
  updateSelectionHighlight();

  interaction = {
    kind: 'move-project',
    card,
    project,
    startPointer: screenToWorld(event.clientX, event.clientY),
    originX: project.x,
    originY: project.y,
  };

  event.preventDefault();
  event.stopPropagation();
});

// Named (not inline-anonymous) so the teardown function at the bottom of
// this file can remove them by reference when the Forest panel unmounts —
// briizOS.local's panel system can remount this component, unlike
// Projungle's own tab bar where it only ever booted once.
function onForestPointerMove(event) {
  if (!interaction) return;

  if (interaction.kind === 'pan') {
    state.viewport.x = interaction.startX + (event.clientX - interaction.startClientX);
    state.viewport.y = interaction.startY + (event.clientY - interaction.startClientY);
    applyTransform();
    return;
  }

  if (interaction.kind === 'move-project') {
    if (!interaction.dragging) {
      lockDragSelection();
      interaction.card.classList.add('forest-dragging');
      interaction.dragging = true;
    }
    const point = screenToWorld(event.clientX, event.clientY);
    interaction.project.x = interaction.originX + (point.x - interaction.startPointer.x);
    interaction.project.y = interaction.originY + (point.y - interaction.startPointer.y);
    interaction.card.style.left = `${interaction.project.x}px`;
    interaction.card.style.top = `${interaction.project.y}px`;
    if (interaction.project.id === state.hunterProjectId) positionHunterPanel();
  }

  if (interaction.kind === 'pan-cover') {
    const dx = event.clientX - interaction.startClientX;
    const dy = event.clientY - interaction.startClientY;
    /* invert: dragging right moves the viewport left, revealing the right side */
    const sensitivity = 0.25;
    const newX = clamp(interaction.originX - (dx * sensitivity / interaction.containerW) * 100, 0, 100);
    const newY = clamp(interaction.originY - (dy * sensitivity / interaction.containerH) * 100, 0, 100);
    interaction.coverImg.style.objectPosition = `${newX}% ${newY}%`;
    interaction.currentX = newX;
    interaction.currentY = newY;
  }
}
window.addEventListener('pointermove', onForestPointerMove);

function onForestPointerUp() {
  if (!interaction) return;
  if (interaction.kind === 'move-project' && interaction.dragging) {
    interaction.card.classList.remove('forest-dragging');
  }
  if (interaction.kind === 'pan-cover' && interaction.currentX != null) {
    interaction.project.coverPosition = `${Math.round(interaction.currentX)}% ${Math.round(interaction.currentY)}%`;
    scheduleSave();
  }
  interaction = null;
  forestShell.classList.remove('is-panning');
  scheduleSave();
}
window.addEventListener('pointerup', onForestPointerUp);

function onForestWindowBlur() {
  interaction = null;
  forestShell.classList.remove('is-panning');
}
window.addEventListener('blur', onForestWindowBlur);

stage.addEventListener('wheel', (event) => {
  if (event.target.closest('.file-list') && !event.ctrlKey) return;

  event.preventDefault();
  const multiplier = Math.exp(-event.deltaY * 0.0015);
  zoomAt(event.clientX, event.clientY, multiplier);
}, { passive: false });

world.addEventListener('click', async (event) => {
  const actionEl = event.target.closest('[data-action]');
  if (!actionEl) return;

  const card = event.target.closest('.project-card');
  const projectId = card?.dataset.id || actionEl.dataset.projectId;
  const project = projectId ? getProject(projectId) : null;

  switch (actionEl.dataset.action) {
    case 'project-files-tab':
      if (project) { state.projectTabs[project.id] = actionEl.dataset.tab; render(); }
      break;
    case 'filehawk-designate':
      designateFile(project, actionEl.dataset.fileId, actionEl.dataset.watch === 'true');
      break;
    case 'toggle-expand': {
      if (!project) return;
      project.expanded = !project.expanded;
      render();
      scheduleSave();
      break;
    }

    case 'tag-filter': {
      const tag = cleanTag(actionEl.dataset.tag);
      if (!tag) return;

      if (event.shiftKey && project) {
        project.tags = project.tags.filter((entry) => entry !== tag);
        render();
        scheduleSave();
        return;
      }

      searchInput.value = `#${tag}`;
      state.query = searchInput.value;
      render();
      break;
    }

    case 'open-file': {
      await openFile(actionEl.dataset.projectId, actionEl.dataset.fileId);
      break;
    }

    case 'show-file': {
      event.stopPropagation();
      await revealFile(actionEl.dataset.projectId, actionEl.dataset.fileId);
      break;
    }

    case 'delete-tag': {
      event.stopPropagation();
      if (!project) return;
      const tagToDelete = cleanTag(actionEl.dataset.tag);
      project.tags = project.tags.filter((t) => t !== tagToDelete);
      render();
      scheduleSave();
      break;
    }

    case 'open-viewer': {
      event.stopPropagation();
      if (projectId) openViewer(projectId);
      break;
    }

    case 'hunter-search': {
      event.stopPropagation();
      if (projectId) openHunter(projectId);
      break;
    }

    case 'consolidate': {
      event.stopPropagation();
      if (projectId) consolidateFiles(projectId);
      break;
    }

    case 'set-cover': {
      event.stopPropagation();
      if (!project) return;
      const fid = actionEl.dataset.fileId;
      project.coverFileId = project.coverFileId === fid ? null : fid;
      project.coverPosition = '50% 50%';
      render();
      scheduleSave();
      break;
    }

    case 'remove-cover': {
      event.stopPropagation();
      if (!project) return;
      project.coverFileId = null;
      project.coverPosition = '50% 50%';
      render();
      scheduleSave();
      break;
    }

    default:
      break;
  }
});

world.addEventListener('dblclick', (event) => {
  const label = event.target.closest('.project-title-label');
  if (!label) return;

  const card = label.closest('.project-card');
  const project = getProject(card?.dataset.id);
  if (!project) return;

  const input = document.createElement('input');
  input.className = 'project-title-input';
  input.spellcheck = false;
  input.autocomplete = 'off';
  input.value = project.name;
  label.replaceWith(input);
  input.focus();
  input.select();
});

world.addEventListener('keydown', (event) => {
  if (event.target.matches('.project-title-input') && event.key === 'Enter') {
    event.preventDefault();
    event.target.blur();
    return;
  }

  if (event.target.matches('.project-title-input') && event.key === 'Escape') {
    event.preventDefault();
    const card = event.target.closest('.project-card');
    const project = getProject(card?.dataset.id);
    if (project) {
      const span = document.createElement('span');
      span.className = 'project-title-label';
      span.dataset.role = 'project-title';
      span.textContent = project.name;
      event.target.replaceWith(span);
    }
    return;
  }

  if (event.target.matches('.tag-input') && event.key === 'Enter') {
    event.preventDefault();

    const project = getProject(event.target.closest('.project-card')?.dataset.id);
    if (!project) return;

    const tag = cleanTag(event.target.value);
    if (!tag) return;

    project.tags = dedupe([...project.tags, tag]);
    event.target.value = '';
    render();
    scheduleSave();
  }
});

world.addEventListener('blur', (event) => {
  if (!event.target.matches('.project-title-input')) return;

  const card = event.target.closest('.project-card');
  const project = getProject(card?.dataset.id);
  if (!project) return;

  const nextName = event.target.value.trim() || 'Untitled Project';
  project.name = nextName;

  const span = document.createElement('span');
  span.className = 'project-title-label';
  span.dataset.role = 'project-title';
  span.textContent = nextName;
  event.target.replaceWith(span);

  /* update emblem if name changed */
  const emblem = card?.querySelector('.project-emblem');
  if (emblem) emblem.textContent = (nextName.trim().slice(0, 1) || 'P').toUpperCase();

  scheduleSave();
}, true);

searchInput.addEventListener('input', () => {
  state.query = searchInput.value.trim();
  render();
});

searchInput.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    searchInput.value = '';
    state.query = '';
    render();
    searchInput.blur();
  }

  if (event.key === 'Enter') {
    fitProjects();
  }
});

// Adds or removes one `#tag` token in the search query without touching the
// rest of it, so several tag flowers can bloom at once alongside typed terms.
function setTagFilter(tag, on) {
  const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`(^|\\s)#${escaped}(?=\\s|$)`, 'gi');
  const without = state.query.replace(pattern, ' ').replace(/\s+/g, ' ').trim();
  state.query = on ? `${without} #${tag}`.trim() : without;
  searchInput.value = state.query;
  render();
}

tagStrip.addEventListener('click', (event) => {
  const slot = event.target.closest('.global-tag-slot');
  if (!slot) return;

  const tag = cleanTag(slot.querySelector('.global-tag')?.dataset.tag);
  if (!tag) return;

  if (!slot.classList.contains('is-bloomed')) {
    setTagFilter(tag, true);
    return;
  }

  // Let the wilt animation play before the re-render removes the flower.
  if (slot.classList.contains('is-wilting')) return;
  slot.classList.remove('is-sprouting');
  slot.classList.add('is-wilting');
  setTimeout(() => {
    if (destroyed || !tagStrip.isConnected) return;
    bloomedTags.delete(normalizeText(tag));
    setTagFilter(tag, false);
  }, 320);
});

/* ── Tag editing: double-click to edit ──────────────────────────────── */

world.addEventListener('dblclick', (event) => {
  const chip = event.target.closest('.tag-chip');
  if (!chip) return;

  const card = event.target.closest('.project-card');
  const project = getProject(card?.dataset.id);
  if (!project || !project.expanded) return;

  event.preventDefault();
  event.stopPropagation();

  const oldTag = cleanTag(chip.dataset.tag);
  if (!oldTag) return;

  project.tags = project.tags.filter((t) => t !== oldTag);
  render();
  scheduleSave();

  requestAnimationFrame(() => {
    const updatedCard = world.querySelector(`.project-card[data-id="${project.id}"]`);
    const input = updatedCard?.querySelector('.tag-input');
    if (input) {
      input.value = oldTag;
      input.focus();
      input.select();
    }
  });
});

/* ── Viewer event handlers ─────────────────────────────────────────── */

/* Save modal field changes back to milestone */
function commitModalFields() {
  const project = getProject(state.viewerProjectId);
  if (!project || !state.viewerActiveModal) return;
  const ms = project.milestones.find((m) => m.id === state.viewerActiveModal);
  if (!ms) return;

  const labelEl = projectViewer.querySelector(`[data-role="modal-milestone-label"][data-milestone-id="${ms.id}"]`);
  const dateEl = projectViewer.querySelector(`[data-role="modal-milestone-date"][data-milestone-id="${ms.id}"]`);
  const daysEl = projectViewer.querySelector(`[data-role="modal-milestone-days"][data-milestone-id="${ms.id}"]`);
  const descEl = projectViewer.querySelector(`[data-role="modal-milestone-desc"][data-milestone-id="${ms.id}"]`);

  let changed = false;
  if (labelEl && labelEl.value.trim() && labelEl.value.trim() !== ms.label) { ms.label = labelEl.value.trim(); changed = true; }
  if (dateEl && dateEl.value && dateEl.value !== ms.date) { ms.date = dateEl.value; changed = true; }
  if (daysEl) { const v = Number(daysEl.value) || 0; if (v !== ms.estimatedDays) { ms.estimatedDays = v; changed = true; } }
  if (descEl && descEl.value !== ms.description) { ms.description = descEl.value; changed = true; }

  if (changed) { render(); scheduleSave(); }
}

async function commitProjectScoringField(project, field, rawValue) {
  if (!project || !['deadline', 'importance', 'size', 'relevance'].includes(field)) return;
  const previous = project[field];
  let value = rawValue;
  if (field === 'importance') {
    value = rawValue === '' ? null : Math.round(Number(rawValue));
    if (value !== null && (!Number.isFinite(value) || value < 1 || value > 10)) {
      refreshViewer();
      return;
    }
  } else if (field === 'size') {
    value = rawValue === '' ? null : Number(rawValue);
    if (value !== null && (!Number.isFinite(value) || value < 0)) {
      refreshViewer();
      return;
    }
  } else if (field === 'deadline') {
    value = rawValue || null;
  } else {
    value = rawValue.trim() || null;
  }

  project[field] = value;
  try {
    const latestState = await window.api.forestLoadState();
    if (destroyed) return;
    const latest = (latestState?.projects || []).find((candidate) => candidate.id === project.id);
    if (!latest?.revision) throw new Error('Could not resolve the latest project revision');
    const result = await window.api.localData.forestProjects.updateScoring(
      project.id,
      latest.revision,
      { [field]: value },
    );
    project[field] = result?.row?.[field] ?? (field === 'importance' || field === 'size' ? null : '');
    render();
    refreshViewer();
    dispatchForestLog('info', 'Project priority signal updated', {
      projectId: project.id,
      project: project.name,
      field,
      value: project[field],
    });
  } catch (error) {
    project[field] = previous;
    refreshViewer();
    dispatchForestLog('error', 'Project priority signal update failed', {
      projectId: project.id,
      field,
      error: error?.message || 'Unknown error',
    });
  }
}

projectViewer.addEventListener('click', async (event) => {
  const actionEl = event.target.closest('[data-action]');
  if (!actionEl) return;

  const project = getProject(state.viewerProjectId);

  switch (actionEl.dataset.action) {
    case 'close-viewer':
      commitModalFields();
      closeViewer();
      break;

    case 'open-milestone-modal': {
      commitModalFields();
      const mid = actionEl.dataset.milestoneId;
      state.viewerActiveModal = state.viewerActiveModal === mid ? null : mid;
      refreshViewer();
      break;
    }

    case 'close-milestone-modal': {
      commitModalFields();
      state.viewerActiveModal = null;
      refreshViewer();
      break;
    }

    case 'toggle-add-mode': {
      state.tlAddMode = !state.tlAddMode;
      if (!state.tlAddMode) {
        state.tlGhost = null;
        state.tlPending = null;
        state.tlHoverDate = null;
      }
      refreshViewer();
      break;
    }

    case 'toggle-milestone': {
      if (!project) return;
      const ms = project.milestones.find((m) => m.id === actionEl.dataset.milestoneId);
      if (ms) {
        ms.completed = !ms.completed;
        refreshViewer();
        render();
        scheduleSave();
      }
      break;
    }

    case 'delete-milestone': {
      if (!project) return;
      if (state.viewerActiveModal === actionEl.dataset.milestoneId) state.viewerActiveModal = null;
      project.milestones = project.milestones.filter((m) => m.id !== actionEl.dataset.milestoneId);
      refreshViewer();
      render();
      scheduleSave();
      break;
    }

    case 'add-milestone-inline': {
      if (!project) return;
      const newId = uid();
      project.milestones.push({
        id: newId,
        label: 'New Milestone',
        date: new Date().toISOString().slice(0, 10),
        completed: false,
        description: '',
        estimatedDays: 0,
        fileIds: [],
        subtasks: [],
      });
      state.viewerActiveModal = newId;
      refreshViewer();
      render();
      scheduleSave();
      /* focus the title input */
      requestAnimationFrame(() => {
        const titleInput = projectViewer.querySelector(`[data-role="modal-milestone-label"][data-milestone-id="${newId}"]`);
        if (titleInput) { titleInput.select(); titleInput.focus(); }
      });
      break;
    }

    case 'toggle-tag-filter': {
      const tag = actionEl.dataset.tag;
      if (state.viewerTagFilter.has(tag)) {
        state.viewerTagFilter.delete(tag);
      } else {
        state.viewerTagFilter.add(tag);
      }
      refreshViewer();
      break;
    }

    case 'clear-tag-filter': {
      state.viewerTagFilter = new Set();
      refreshViewer();
      break;
    }

    case 'zoom-fit':
      if (project) zoomToFit(project);
      break;

    case 'next-node':
      if (project) jumpToNextNode(project);
      break;

    case 'toggle-subtask': {
      event.preventDefault();
      if (!project) return;
      const ms = project.milestones.find((m) => m.id === actionEl.dataset.milestoneId);
      if (!ms) return;
      const sub = (ms.subtasks || []).find((s) => s.id === actionEl.dataset.subtaskId);
      if (sub) {
        sub.done = !sub.done;
        refreshViewer();
        render();
        scheduleSave();
      }
      break;
    }

    case 'delete-subtask': {
      event.preventDefault();
      event.stopPropagation();
      if (!project) return;
      const ms = project.milestones.find((m) => m.id === actionEl.dataset.milestoneId);
      if (!ms) return;
      ms.subtasks = (ms.subtasks || []).filter((s) => s.id !== actionEl.dataset.subtaskId);
      refreshViewer();
      render();
      scheduleSave();
      break;
    }

    case 'toggle-file-link': {
      event.preventDefault();
      if (!project) return;
      const ms = project.milestones.find((m) => m.id === actionEl.dataset.milestoneId);
      if (!ms) return;
      const fid = actionEl.dataset.fileId;
      const idx = ms.fileIds.indexOf(fid);
      if (idx >= 0) { ms.fileIds.splice(idx, 1); } else { ms.fileIds.push(fid); }
      refreshViewer();
      render();
      scheduleSave();
      break;
    }

    case 'open-file': {
      await openFile(actionEl.dataset.projectId, actionEl.dataset.fileId);
      break;
    }

    case 'show-file': {
      event.stopPropagation();
      await revealFile(actionEl.dataset.projectId, actionEl.dataset.fileId);
      break;
    }

    default:
      break;
  }
});

/* Modal input change listeners */
projectViewer.addEventListener('change', async (event) => {
  const role = event.target.dataset?.role;
  if (!role) return;
  const project = getProject(state.viewerProjectId);
  if (!project) return;
  if (role.startsWith('project-score-')) {
    await commitProjectScoringField(project, role.slice('project-score-'.length), event.target.value);
    return;
  }
  const mid = event.target.dataset.milestoneId;
  const ms = mid ? project.milestones.find((m) => m.id === mid) : null;

  if (role === 'modal-milestone-date' && ms) {
    ms.date = event.target.value || ms.date;
    refreshViewer();
    render();
    scheduleSave();
  }
  if (role === 'modal-milestone-days' && ms) {
    ms.estimatedDays = Number(event.target.value) || 0;
    render();
    scheduleSave();
  }
});

projectViewer.addEventListener('input', (event) => {
  /* live-save description as you type */
  if (event.target.dataset?.role === 'modal-milestone-desc') {
    const project = getProject(state.viewerProjectId);
    if (!project) return;
    const ms = project.milestones.find((m) => m.id === event.target.dataset.milestoneId);
    if (ms) { ms.description = event.target.value; scheduleSave(); }
  }
});

/* Hover-to-play for video/audio previews in viewer */
projectViewer.addEventListener('mouseenter', (event) => {
  const item = event.target.closest('.viewer-carousel-item');
  if (!item) return;
  const media = item.querySelector('video, audio');
  if (media) media.play().catch(() => {});
}, true);

projectViewer.addEventListener('mouseleave', (event) => {
  const item = event.target.closest('.viewer-carousel-item');
  if (!item) return;
  const media = item.querySelector('video, audio');
  if (media) { media.pause(); media.currentTime = 0; }
}, true);

projectViewer.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    if (state.viewerActiveModal) {
      commitModalFields();
      state.viewerActiveModal = null;
      refreshViewer();
      return;
    }
    closeViewer();
    return;
  }

  /* Enter in subtask input → add subtask */
  if (event.key === 'Enter' && event.target.matches('[data-role="subtask-input"]')) {
    event.preventDefault();
    const text = event.target.value.trim();
    if (!text) return;
    const project = getProject(state.viewerProjectId);
    if (!project) return;
    const ms = project.milestones.find((m) => m.id === event.target.dataset.milestoneId);
    if (!ms) return;
    if (!ms.subtasks) ms.subtasks = [];
    ms.subtasks.push({ id: uid(), text, done: false });
    refreshViewer();
    render();
    scheduleSave();
    requestAnimationFrame(() => {
      const input = projectViewer.querySelector(`[data-role="subtask-input"][data-milestone-id="${ms.id}"]`);
      if (input) input.focus();
    });
    return;
  }

  /* Enter in modal title → blur */
  if (event.key === 'Enter' && event.target.matches('[data-role="modal-milestone-label"]')) {
    event.preventDefault();
    commitModalFields();
    refreshViewer();
  }
});

/* ── Milestone drag-to-reorder ───────────────────────────────────────── */

projectViewer.addEventListener('mousedown', (event) => {
  const dot = event.target.closest('.tl-dot');
  if (!dot) return;
  /* only start drag on left button */
  if (event.button !== 0) return;

  const node = dot.closest('.tl-node');
  const track = dot.closest('.tl-track');
  if (!node || !track) return;

  const milestoneId = node.dataset.milestoneId;
  const trackRect = track.getBoundingClientRect();

  state.viewerDrag = {
    milestoneId,
    startX: event.clientX,
    trackLeft: trackRect.left,
    trackWidth: trackRect.width,
    moved: false,
  };

  lockDragSelection();
  node.classList.add('forest-dragging');
  track.classList.add('drag-active');
  event.preventDefault();
});

function onForestDocumentMouseMove(event) {
  if (!state.viewerDrag) return;
  const drag = state.viewerDrag;
  const dx = Math.abs(event.clientX - drag.startX);
  if (dx > 4) drag.moved = true;
  if (!drag.moved) return;

  const node = projectViewer.querySelector(`.tl-node[data-milestone-id="${drag.milestoneId}"]`);
  if (!node) return;

  const pct = clamp(((event.clientX - drag.trackLeft) / drag.trackWidth) * 100, 0, 100);
  node.style.left = `${pct}%`;
  node.style.zIndex = '10';
}
document.addEventListener('mousemove', onForestDocumentMouseMove);

function onForestDocumentMouseUp(event) {
  if (state.tlPan) {
    state.tlPan = null;
    const track = projectViewer.querySelector('.tl-track');
    if (track) track.classList.remove('panning');
  }

  if (!state.viewerDrag) return;
  const drag = state.viewerDrag;
  state.viewerDrag = null;

  const node = projectViewer.querySelector(`.tl-node[data-milestone-id="${drag.milestoneId}"]`);
  const track = projectViewer.querySelector('.tl-track');
  if (node) { node.classList.remove('forest-dragging'); node.style.zIndex = ''; }
  if (track) track.classList.remove('drag-active');

  if (!drag.moved) return; /* was a click, not a drag */

  const project = getProject(state.viewerProjectId);
  if (!project) return;

  const milestones = project.milestones;
  const sorted = [...milestones].sort((a, b) => a.date.localeCompare(b.date));
  const dragIdx = sorted.findIndex((m) => m.id === drag.milestoneId);
  if (dragIdx < 0) return;

  const finalPct = clamp(((event.clientX - drag.trackLeft) / drag.trackWidth) * 100, 0, 100);
  const totalNodes = sorted.length;
  let targetIdx = Math.round((finalPct / 100) * (totalNodes - 1));
  targetIdx = clamp(targetIdx, 0, totalNodes - 1);

  if (targetIdx === dragIdx) { refreshViewer(); return; }

  /* reorder by updating the dragged milestone's date to slot into new position */
  const dragged = sorted[dragIdx];
  sorted.splice(dragIdx, 1);

  let newDate;
  if (targetIdx === 0) {
    const nextDate = new Date(sorted[0].date + 'T00:00:00');
    nextDate.setDate(nextDate.getDate() - 1);
    newDate = nextDate.toISOString().slice(0, 10);
  } else if (targetIdx >= sorted.length) {
    const prevDate = new Date(sorted[sorted.length - 1].date + 'T00:00:00');
    prevDate.setDate(prevDate.getDate() + 1);
    newDate = prevDate.toISOString().slice(0, 10);
  } else {
    const before = new Date(sorted[targetIdx - 1].date + 'T00:00:00');
    const after = new Date(sorted[targetIdx].date + 'T00:00:00');
    const midMs = (before.getTime() + after.getTime()) / 2;
    newDate = new Date(midMs).toISOString().slice(0, 10);
  }

  dragged.date = newDate;
  refreshViewer();
  render();
  scheduleSave();
}
document.addEventListener('mouseup', onForestDocumentMouseUp);

/* ── Timeline ghost node and interaction handlers ──────────────────────── */

projectViewer.addEventListener('mousedown', (event) => {
  const track = event.target.closest('.tl-track');
  if (!track || !state.viewerProjectId) return;
  
  // If clicking a node or modal, don't start panning
  if (event.target.closest('.tl-node')) return;
  if (event.target.closest('.tl-modal')) return;
  if (event.target.closest('button')) return;

  state.tlPan = {
    startX: event.clientX,
    startViewport: { 
      start: new Date(state.tlViewport.start), 
      end: new Date(state.tlViewport.end) 
    }
  };
  
  track.classList.add('panning');
  event.preventDefault();
});

projectViewer.addEventListener('mousemove', (event) => {
  const track = event.target.closest('.tl-track');
  
  if (state.tlPan) {
    const dx = event.clientX - state.tlPan.startX;
    const trackWidth = track ? track.getBoundingClientRect().width : 800;
    
    const viewport = state.tlPan.startViewport;
    const totalMs = viewport.end.getTime() - viewport.start.getTime();
    const msPerPx = totalMs / trackWidth;
    const msDelta = dx * msPerPx;
    
    state.tlViewport = {
      start: new Date(viewport.start.getTime() - msDelta),
      end: new Date(viewport.end.getTime() - msDelta)
    };
    
    state.tlGhost = null;
    state.tlHoverDate = null;
    refreshViewer();
    return;
  }

  // Add-milestone hover preview only in add mode, and never while a milestone
  // modal is open (keeps the open modal stable). Otherwise hovering does nothing.
  if (!state.tlAddMode || state.viewerActiveModal) {
    if (state.tlGhost || state.tlHoverDate) {
      state.tlGhost = null;
      state.tlHoverDate = null;
      refreshViewer();
    }
    return;
  }

  if (!track || !state.viewerProjectId) {
    state.tlGhost = null;
    state.tlHoverDate = null;
    refreshViewer();
    return;
  }

  if (state.viewerDrag) return;

  const project = getProject(state.viewerProjectId);
  if (!project) return;

  const milestones = project.milestones || [];
  if (milestones.length === 0) {
    const trackRect = track.getBoundingClientRect();
    const x = event.clientX - trackRect.left - 40;
    const trackWidth = trackRect.width - 80;
    const now = new Date();
    const dateMs = now.getTime();
    
    if (state.tlViewport.start) {
      const pct = ((dateMs - state.tlViewport.start.getTime()) / (state.tlViewport.end.getTime() - state.tlViewport.start.getTime())) * 100;
      const clampedPct = Math.max(5, Math.min(95, pct));
      const snappedDate = snapDateToUnit(now, state.tlZoom);
      state.tlGhost = { pct: clampedPct, date: now, snappedDate };
      state.tlHoverDate = snappedDate;
    } else {
      state.tlGhost = null;
      state.tlHoverDate = null;
    }
    refreshViewer();
    return;
  }

  const trackRect = track.getBoundingClientRect();
  const x = event.clientX - trackRect.left - 40;
  const trackWidth = trackRect.width - 80;
  
  if (x < 0 || x > trackWidth) {
    state.tlGhost = null;
    state.tlHoverDate = null;
    refreshViewer();
    return;
  }

  const sorted = [...milestones].sort((a, b) => a.date.localeCompare(b.date));
  const firstMs = new Date(sorted[0].date + 'T00:00:00').getTime();
  const lastMs = new Date(sorted[sorted.length - 1].date + 'T00:00:00').getTime();
  const totalMs = lastMs - firstMs || 1;
  const padding = totalMs * 0.1;
  const adjustedStart = firstMs - padding;
  const adjustedEnd = lastMs + padding;
  
  const totalRange = adjustedEnd - adjustedStart;
  const dateMs = adjustedStart + (x / trackWidth) * totalRange;
  const date = new Date(dateMs);
  const snappedDate = snapDateToUnit(date, state.tlZoom);
  
  const pct = (x / trackWidth) * 100;
  const clampedPct = Math.max(0, Math.min(100, pct));
  
  state.tlGhost = { pct: clampedPct, date, snappedDate };
  state.tlHoverDate = snappedDate;
  refreshViewer();
});

projectViewer.addEventListener('mouseleave', (event) => {
  state.tlPan = null;
  const track = event.target.closest('.tl-track');
  if (track) {
    track.classList.remove('panning');
    state.tlGhost = null;
    state.tlHoverDate = null;
    refreshViewer();
  }
});

projectViewer.addEventListener('click', (event) => {
  const track = event.target.closest('.tl-track');
  const project = getProject(state.viewerProjectId);
  if (!project) return;

  const milestones = project.milestones || [];

  if (event.target.closest('.tl-node')) return;
  if (event.target.closest('.tl-dot')) return;
  if (event.target.closest('.tl-modal')) return;
  if (event.target.closest('button')) return;

  if (!state.tlAddMode) return; // only place milestones while "+ Add" is toggled on

  if (state.tlPending) {
    const newId = uid();
    const dateStr = state.tlPending.toISOString().slice(0, 10);
    project.milestones.push({
      id: newId,
      label: 'New Milestone',
      date: dateStr,
      completed: false,
      description: '',
      estimatedDays: 0,
      fileIds: [],
      subtasks: [],
    });
    state.tlPending = null;
    state.viewerActiveModal = newId;
    state.tlGhost = null;
    refreshViewer();
    render();
    scheduleSave();
    requestAnimationFrame(() => {
      const titleInput = projectViewer.querySelector(`[data-role="modal-milestone-label"][data-milestone-id="${newId}"]`);
      if (titleInput) { titleInput.select(); titleInput.focus(); }
    });
    return;
  }

  if (milestones.length === 0) {
    const newId = uid();
    const now = new Date();
    project.milestones.push({
      id: newId,
      label: 'New Milestone',
      date: now.toISOString().slice(0, 10),
      completed: false,
      description: '',
      estimatedDays: 0,
      fileIds: [],
      subtasks: [],
    });
    state.viewerActiveModal = newId;
    state.tlGhost = null;
    initTimelineViewport(project);
    refreshViewer();
    render();
    scheduleSave();
    requestAnimationFrame(() => {
      const titleInput = projectViewer.querySelector(`[data-role="modal-milestone-label"][data-milestone-id="${newId}"]`);
      if (titleInput) { titleInput.select(); titleInput.focus(); }
    });
    return;
  }

  if (state.tlHoverDate) {
    if (state.tlZoom >= 2) {
      const newId = uid();
      const dateStr = state.tlHoverDate.toISOString().slice(0, 10);
      project.milestones.push({
        id: newId,
        label: 'New Milestone',
        date: dateStr,
        completed: false,
        description: '',
        estimatedDays: 0,
        fileIds: [],
        subtasks: [],
      });
      state.viewerActiveModal = newId;
      state.tlGhost = null;
      refreshViewer();
      render();
      scheduleSave();
      requestAnimationFrame(() => {
        const titleInput = projectViewer.querySelector(`[data-role="modal-milestone-label"][data-milestone-id="${newId}"]`);
        if (titleInput) { titleInput.select(); titleInput.focus(); }
      });
    } else {
      state.tlPending = state.tlHoverDate;
      state.tlZoom = 2;
      refreshViewer();
    }
  }
});

projectViewer.addEventListener('wheel', (event) => {
  const track = event.target.closest('.tl-track');
  if (!track) return;
  
  const project = getProject(state.viewerProjectId);
  if (!project) return;

  const milestones = project.milestones || [];
  if (milestones.length === 0) return;

  event.preventDefault();

  const trackRect = track.getBoundingClientRect();
  const mouseX = event.clientX - trackRect.left - 40;
  const trackWidth = trackRect.width - 80;
  
  if (mouseX < -40 || mouseX > trackWidth + 40) return;

  if (!state.tlViewport.start || !state.tlViewport.end) {
    initTimelineViewport(project);
  }

  const { start, end } = state.tlViewport;
  const totalMs = end.getTime() - start.getTime();
  const mousePct = mouseX / trackWidth;
  const targetDateMs = start.getTime() + mousePct * totalMs;

  // Slower zoom factor: 1.03 instead of 1.1
  const zoomIn = event.deltaY < 0;
  const factor = Math.pow(1.035, zoomIn ? -1 : 1);
  
  // Adjusted range: 1 hour to 2 years
  const minRange = 1000 * 60 * 60; // 1 hour
  const maxRange = 1000 * 60 * 60 * 24 * 365 * 2; // 2 years
  const newTotalMs = clamp(totalMs * factor, minRange, maxRange);
  
  const newStartMs = targetDateMs - mousePct * newTotalMs;
  const newEndMs = newStartMs + newTotalMs;
  
  state.tlViewport = {
    start: new Date(newStartMs),
    end: new Date(newEndMs)
  };

  // Expanded tlZoom levels for more detail: 1: Years, 2: Months, 3: Days, 4: Hours
  const days = newTotalMs / (1000 * 60 * 60 * 24);
  if (days > 180) state.tlZoom = 1;      // Shows years/months
  else if (days > 14) state.tlZoom = 2; // Shows months/days
  else if (days > 2) state.tlZoom = 3;  // Shows days/hours
  else state.tlZoom = 4;                // Shows hourly detail
  
  refreshViewer();
}, { passive: false });

/* ── Hunter panel event handlers ───────────────────────────────────── */

hunterPanel.addEventListener('click', async (event) => {
  const actionEl = event.target.closest('[data-action]');
  if (!actionEl) return;

  switch (actionEl.dataset.action) {
    case 'close-hunter':
      closeHunter();
      break;

    case 'hunter-type': {
      const t = actionEl.dataset.type;
      if (state.hunterTypes.has(t)) state.hunterTypes.delete(t);
      else state.hunterTypes.add(t);
      renderHunterPanel();
      runHunterSearch();
      break;
    }

    case 'hunter-add-file': {
      event.stopPropagation();
      const project = getProject(state.hunterProjectId);
      if (!project) return;
      const fileRecord = state.hunterResults.find((f) => f.path === actionEl.dataset.path);
      if (!fileRecord) return;
      if (!project.files.some((f) => f.path === fileRecord.path)) {
        project.files.push(normalizeFile(fileRecord));
        project.files.sort(sortFiles);
      }
      state.hunterResults = state.hunterResults.filter((f) => f.path !== fileRecord.path);
      state.hunterSelected.delete(fileRecord.path);
      refreshHunterResults();
      render();
      scheduleSave();
      break;
    }

    case 'hunter-add-selected': {
      event.stopPropagation();
      const project = getProject(state.hunterProjectId);
      if (!project) return;
      const chosen = state.hunterResults.filter((f) => state.hunterSelected.has(f.path));
      chosen.forEach((fileRecord) => {
        if (!project.files.some((f) => f.path === fileRecord.path)) {
          project.files.push(normalizeFile(fileRecord));
        }
      });
      project.files.sort(sortFiles);
      const added = new Set(chosen.map((f) => f.path));
      state.hunterResults = state.hunterResults.filter((f) => !added.has(f.path));
      state.hunterSelected = new Set();
      refreshHunterResults();
      render();
      scheduleSave();
      break;
    }

    case 'hunter-relink': {
      event.stopPropagation();
      const project = getProject(state.hunterProjectId);
      const rel = state.hunterRelocate;
      if (!project || !rel) return;
      const file = project.files.find((f) => f.id === rel.fileId);
      const chosen = state.hunterResults.find((r) => r.path === actionEl.dataset.path);
      if (file && chosen) {
        file.path = chosen.path;
        file.name = chosen.name;
        file.ext = chosen.ext;
        file.size = chosen.size;
        file.modifiedAt = chosen.modifiedAt;
        file.typeGroup = chosen.typeGroup;
        file.previewable = chosen.previewable;
        state.filehawkStatus[file.path] = 'ok';
      }
      closeHunter();
      render();
      scheduleSave();
      if (state.filehawkOpen) filehawkScan();
      break;
    }

    case 'hunter-add-dir': {
      event.stopPropagation();
      const dir = await window.api.forestOpenDirectoryDialog();
      if (destroyed || !dir) return;
      if (!state.hunterDirs.includes(dir)) {
        state.hunterDirs.push(dir);
        renderHunterPanel();
        scheduleSave();
        if (state.hunterRelocate) {
          const project = getProject(state.hunterProjectId);
          const file = project?.files.find((f) => f.id === state.hunterRelocate.fileId);
          if (project && file) openHunterRelocate(project.id, file);
        } else {
          runHunterSearch();
        }
      }
      break;
    }

    case 'hunter-remove-dir': {
      event.stopPropagation();
      const idx = Number(actionEl.dataset.index);
      if (idx >= 0 && idx < state.hunterDirs.length) {
        state.hunterDirs.splice(idx, 1);
        renderHunterPanel();
        scheduleSave();
        if (!state.hunterRelocate) runHunterSearch();
      }
      break;
    }

    default:
      break;
  }
});

/* Hunter: debounced query typing */
hunterPanel.addEventListener('input', (event) => {
  if (!event.target.matches('[data-role="hunter-query"]')) return;
  state.hunterQueryStr = event.target.value;
  clearTimeout(hunterDebounce);
  hunterDebounce = setTimeout(() => runHunterSearch(), 280);
});

/* Hunter: result multi-select */
hunterPanel.addEventListener('change', (event) => {
  const cb = event.target.closest('[data-action="hunter-select"]');
  if (!cb) return;
  const p = cb.dataset.path;
  if (cb.checked) state.hunterSelected.add(p);
  else state.hunterSelected.delete(p);
  refreshHunterResults();
});

/* FileHawk panel actions */
filehawkPanel.addEventListener('click', async (event) => {
  const actionEl = event.target.closest('[data-action]');
  if (!actionEl) return;

  switch (actionEl.dataset.action) {
    case 'filehawk-unwatch':
      designateFile(getProject(actionEl.dataset.projectId), actionEl.dataset.fileId, false);
      break;
    case 'filehawk-close':
      closeFilehawk();
      break;

    case 'filehawk-rescan':
      filehawkScan();
      break;

    case 'filehawk-remove': {
      if (!window.confirm('Remove this missing file reference from the project? The file itself will not be deleted.')) return;
      const project = getProject(actionEl.dataset.projectId);
      if (!project) return;
      const file = project.files.find((f) => f.id === actionEl.dataset.fileId);
      project.files = project.files.filter((f) => f.id !== actionEl.dataset.fileId);
      if (file) delete state.filehawkStatus[file.path];
      renderFilehawkPanel();
      render();
      scheduleSave();
      break;
    }

    case 'filehawk-relocate': {
      const project = getProject(actionEl.dataset.projectId);
      const file = project?.files.find((f) => f.id === actionEl.dataset.fileId);
      if (project && file) openHunterRelocate(project.id, file);
      break;
    }

    default:
      break;
  }
});

/* ── Sort by activity ──────────────────────────────────────────────── */

sortActivityBtn.addEventListener('click', () => {
  state.sortByActivity = !state.sortByActivity;
  sortActivityBtn.classList.toggle('forest-active', state.sortByActivity);
  render();
});

dimToggle.addEventListener('click', () => {
  // Was document.querySelector('*') — that selects <html> (the first match
  // for '*' in the whole document), toggling dim-mode for all of briizOS.local
  // instead of just Forest. Scoped to forestShell instead.
  forestShell.classList.toggle('dim-mode');
  forestShell.dataset.theme = forestShell.dataset.theme === 'dim' ? '' : 'dim';
});

resetViewBtn.addEventListener('click', () => resetView(true));
fitBtn.addEventListener('click', () => fitProjects());
if (collapseAllBtn) {
  collapseAllBtn.addEventListener('click', () => {
    const expandedProjects = state.projects.filter((project) => project.expanded);
    if (!expandedProjects.length) return;

    expandedProjects.forEach((project) => {
      project.expanded = false;
    });
    render();
    scheduleSave();
  });
}
if (filehawkBtn) filehawkBtn.addEventListener('click', () => (state.filehawkOpen ? closeFilehawk() : openFilehawk()));

function onForestDragEnter(event) {
  if (!isFileDrag(event)) return;
  event.preventDefault();
  dragDepth += 1;
  showDropOverlay();
}
window.addEventListener('dragenter', onForestDragEnter);

function onForestDragOver(event) {
  if (!isFileDrag(event)) return;
  event.preventDefault();
  showDropOverlay();
}
window.addEventListener('dragover', onForestDragOver);

function onForestDragLeave(event) {
  if (!isFileDrag(event)) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) hideDropOverlay();
}
window.addEventListener('dragleave', onForestDragLeave);

function onForestWindowDrop(event) {
  if (!isFileDrag(event)) return;
  dragDepth = 0;
  hideDropOverlay();
}
window.addEventListener('drop', onForestWindowDrop);

stage.addEventListener('dragover', (event) => {
  if (isFileDrag(event)) event.preventDefault();
});

stage.addEventListener('drop', handleDrop);

function onForestResize() {
  applyTransform();
}
window.addEventListener('resize', onForestResize);

function onForestKeyDown(event) {
  if (!host.isConnected || !host.contains(event.target)) return;
  const active = document.activeElement;
  const typingInInput = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') && active !== searchInput;

  if (typingInInput) {
    if (event.key === 'Escape') active.blur();
    return;
  }

  if ((event.metaKey || event.ctrlKey) && event.key === '0') {
    event.preventDefault();
    resetView(true);
  }

  if ((event.metaKey || event.ctrlKey) && (event.key === '=' || event.key === '+')) {
    event.preventDefault();
    const center = getStageCenter();
    zoomAt(center.x, center.y, 1.15);
  }

  if ((event.metaKey || event.ctrlKey) && event.key === '-') {
    event.preventDefault();
    const center = getStageCenter();
    zoomAt(center.x, center.y, 0.87);
  }

  if (event.key === 'Escape' && document.activeElement !== searchInput) {
    if (state.viewerProjectId) { closeViewer(); return; }
    if (state.hunterProjectId) { closeHunter(); return; }
    state.selectedProjectId = null;
    updateSelectionHighlight();
  }
}
window.addEventListener('keydown', onForestKeyDown);

// ── Teardown ────────────────────────────────────────────────────────────
// Dispose only this mount; late loads cannot revive a closed board.
function forestDestroy() {
  if (destroyed) return;
  if (saveTimer) {
    clearTimeout(saveTimer);
    if (loaded) void saveNow();
  }
  destroyed = true;
  clearTimeout(hunterDebounce);
  window.removeEventListener('pointermove', onForestPointerMove);
  window.removeEventListener('pointerup', onForestPointerUp);
  window.removeEventListener('blur', onForestWindowBlur);
  document.removeEventListener('mousemove', onForestDocumentMouseMove);
  document.removeEventListener('mouseup', onForestDocumentMouseUp);
  window.removeEventListener('dragenter', onForestDragEnter);
  window.removeEventListener('dragover', onForestDragOver);
  window.removeEventListener('dragleave', onForestDragLeave);
  window.removeEventListener('drop', onForestWindowDrop);
  window.removeEventListener('resize', onForestResize);
  window.removeEventListener('keydown', onForestKeyDown);
  if (filehawkTimer) {
    clearInterval(filehawkTimer);
    filehawkTimer = null;
  }
}

async function init() {
  setSaveStatus('Loading…');
  try {
    // Let React finish releasing any previous mount before capturing its saves.
    await Promise.resolve();
    await pendingSaves;
    if (destroyed) return;
    const saved = await window.api.forestLoadState();
    if (destroyed) return;

    state.viewport = {
      ...state.viewport,
      ...(saved.viewport || {}),
    };

    state.projects = (saved.projects || []).map(normalizeProject);
    state.hunterDirs = Array.isArray(saved.hunterDirs) ? saved.hunterDirs : [];

    if (!state.projects.length) {
      resetView(false);
    }

    loaded = true;
    render();
    setSaveStatus('Ready');
    startFileHawk();
    dispatchForestLog('info', 'Forest panel loaded', { projectCount: state.projects.length });
  } catch (error) {
    if (destroyed) return;
    console.error(error);
    setSaveStatus('Load failed — retry below');
    emptyState.hidden = false;
    emptyState.replaceChildren();
    const retry = document.createElement('button');
    retry.type = 'button';
    retry.className = 'forest-action-btn';
    retry.textContent = 'Forest could not load. Retry';
    retry.addEventListener('click', () => {
      retry.disabled = true;
      dispatchForestLog('info', 'Retrying Forest board load');
      void init();
    }, { once: true });
    emptyState.appendChild(retry);
    dispatchForestLog('error', 'Forest panel failed to load', error?.message);
  }
}

init();
return forestDestroy;
}
