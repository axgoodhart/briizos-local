/**
 * useBriizyCapture — renderer-side view of the briizy capture pipeline.
 *
 * Holds live status/config, exposes the controls the Notefalls drawer needs, and
 * logs every user-initiated capture action to the LogPanel (Hard Rule 1). All
 * state comes from main over the `briizy:event` push channel, so the panel never
 * polls and never disagrees with the indexer.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import logger from '../lib/logger';
import { briizyApi, isBriizyAvailable, UNAVAILABLE_STATUS } from '../components/notefalls/briizyApi';

export function useBriizyCapture() {
  const [status, setStatus] = useState(UNAVAILABLE_STATUS);
  const [config, setConfig] = useState(null);
  const [defaults, setDefaults] = useState(null);
  const [proposals, setProposals] = useState([]);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [busy, setBusy] = useState(false);
  const mounted = useRef(true);

  const available = isBriizyAvailable();

  const refresh = useCallback(async () => {
    const [nextStatus, nextConfig, nextProposals] = await Promise.all([
      briizyApi.getStatus(),
      briizyApi.getConfig(),
      briizyApi.listProposals({ state: 'pending' }),
    ]);
    if (!mounted.current) return;
    if (nextStatus) setStatus(nextStatus);
    if (nextConfig) setConfig(nextConfig);
    setProposals(nextProposals || []);
  }, []);

  useEffect(() => {
    mounted.current = true;
    refresh();
    briizyApi.getDefaults().then((value) => {
      if (mounted.current && value) setDefaults(value);
    });

    const unsubscribe = briizyApi.onEvent(({ type, payload }) => {
      if (!mounted.current) return;
      if (type === 'status') setStatus(payload);
      else if (type === 'config') setConfig(payload);
      else if (type === 'paused' || type === 'resumed') refresh();
      else if (type === 'proposal') {
        // A proposal can also be decided from the avatar overlay, so the panel
        // takes its list from the same events rather than its own copy.
        setProposals((current) => (
          current.some((existing) => existing.id === payload.id) ? current : [payload, ...current]
        ));
      } else if (type === 'proposal-decided') {
        setProposals((current) => current.filter((existing) => existing.id !== payload?.row?.id));
      }
    });
    return () => {
      mounted.current = false;
      unsubscribe?.();
    };
  }, [refresh]);

  /** Run a control action, keeping the UI honest about in-flight state. */
  const act = useCallback(async (label, run, data) => {
    setBusy(true);
    logger.info('briizy', label, data);
    try {
      const result = await run();
      await refresh();
      return result;
    } catch (error) {
      logger.error('briizy', `${label} failed`, error?.message);
      return null;
    } finally {
      if (mounted.current) setBusy(false);
    }
  }, [refresh]);

  /**
   * The single switch behind the composer's "auto capture is ON/OFF" control.
   *
   * Turning it on for the first time does NOT enable capture — it asks the panel
   * to show the onboarding sheet. I10 requires explicit first-run onboarding, and
   * a toggle click is not informed consent about a tool that reads your screen.
   */
  const toggleCapture = useCallback(async (nextEnabled) => {
    const enable = nextEnabled ?? !status.enabled;
    if (enable && !status.onboarded) {
      logger.info('briizy', 'Capture onboarding requested');
      setNeedsOnboarding(true);
      return null;
    }
    return act(`Capture turned ${enable ? 'on' : 'off'}`, () => briizyApi.setConfig({ enabled: enable }), {
      enabled: enable,
    });
  }, [act, status.enabled, status.onboarded]);

  /** Called only from the onboarding sheet, after the user has read it. */
  const completeOnboarding = useCallback(async ({ enabled, cloudTextAnalysisAllowed }) => {
    setNeedsOnboarding(false);
    return act('Capture onboarding completed',
      () => briizyApi.completeOnboarding({ enabled, cloudTextAnalysisAllowed }),
      { enabled, cloudTextAnalysisAllowed });
  }, [act]);

  const dismissOnboarding = useCallback(() => {
    logger.info('briizy', 'Capture onboarding declined');
    setNeedsOnboarding(false);
  }, []);

  const togglePause = useCallback(async () => {
    const paused = !!status.paused;
    return act(paused ? 'Capture resumed' : 'Capture paused',
      () => (paused ? briizyApi.resume('notefalls') : briizyApi.pause('notefalls')));
  }, [act, status.paused]);

  const toggleDisplaySession = useCallback(async () => {
    const active = status.session?.kind === 'display';
    return act(active ? 'Display session ended' : 'Display session started',
      () => (active ? briizyApi.endDisplaySession() : briizyApi.startDisplaySession()));
  }, [act, status.session?.kind]);

  const updateConfig = useCallback((patch) => (
    act('Capture settings changed', () => briizyApi.setConfig(patch), patch)
  ), [act]);

  const clearHistory = useCallback((scope) => (
    act('Screen history cleared', () => briizyApi.deleteHistory(scope), scope)
  ), [act]);

  /**
   * Decide a proposal. Accept creates a pending, non-automated task and starts
   * nothing (I6) — the label in the UI says so, and this is the call that keeps
   * that promise true.
   */
  const decideProposal = useCallback(async (id, verdict, extra = {}) => {
    setProposals((current) => current.filter((proposal) => proposal.id !== id));
    const result = await act(`Suggestion ${verdict}ed`, () => briizyApi.decideProposal({
      id, verdict, ...extra,
    }), { id, verdict });
    if (result && result.ok === false) {
      logger.warn('briizy', 'Suggestion decision refused', result.reason);
      await refresh();
    }
    return result;
  }, [act, refresh]);

  const updateAssistant = useCallback((assistantId, patch) => (
    act(`Assistant "${assistantId}" settings changed`,
      () => briizyApi.setConfig({ assistants: { [assistantId]: patch } }),
      { assistantId, ...patch })
  ), [act]);

  return {
    available,
    status,
    config,
    defaults,
    proposals,
    needsOnboarding,
    busy,
    refresh,
    toggleCapture,
    completeOnboarding,
    dismissOnboarding,
    togglePause,
    toggleDisplaySession,
    updateConfig,
    updateAssistant,
    decideProposal,
    clearHistory,
  };
}

export default useBriizyCapture;
